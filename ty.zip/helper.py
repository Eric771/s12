# BOT LOGIN
# ıll 𝘗𝘳𝘪𝘯𝘤𝘦 ღ SԋαԋZ𝓲 llı
# id umerch66
#arbi ka liff
#line://app/1653851465-7YLbQe5W?type=fotext&text=Me
#BotEator ka
#line://app/1586794970-VKzbNLP7?type=text&text=Me
#Hamar Liff2.py 
#line://app/1643727178-0XPGAaRX?type=text&text=Me
#Hamara Staff2.py ka 
#line://app/1602687308-GXq4Vvk9?type=text&text=Me
#Api Key List
#auth = "oI5bOiBD4USh"
#auth = "u9vYtPlinJKB"
#auth = "Z6vMBEnkp04n"
from linepy import *
import livejson
from akad.ttypes import Message
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from KhieBots.thrift.protocol import TCompactProtocol
from KhieBots.thrift.transport import THttpClient
from KhieBots.ttypes import LoginRequest
from Naked.toolshed.shell import execute_js
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
#from wikiapi import WikiApi
from tmp.MySplit import *
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
from threading import Thread, activeCount
import LineService
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import time, random, sys, json, null, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=====================================================================
noobcoder = LINE("ajsiri72@gmail.com","Ali2003Ali")
#noobcoder = LINE("shahzain@outlyca.tk","Atifkhan83")
#noobcoder = LINE("prnc1661@gmail.com","prince1661")
#noobcoder = LINE("",appName="IOS\t9.18.1.2019.1028.1835\tiOS\t12.1.4")
#=======================================================
waitOpen = codecs.open("noobcoder/wait.json","r","utf-8")
settingsOpen = codecs.open("noobcoder/temp.json","r","utf-8")
premiumOpen = codecs.open("noobcoder/user.json","r","utf-8")
javaOpen = codecs.open("noobcoder/java.json","r","utf-8")
#=====================================================================
#=====================================================================
noobcoderProfile = noobcoder.getProfile()
noobcoderSettings = noobcoder.getSettings()
noobcoderPoll = OEPoll(noobcoder)
noobcoderMID = noobcoder.getProfile().mid
#=====================================================================
loop = asyncio.get_event_loop()
admin = ["u961d4fd88c0be4aa376b59ef89d4e3ab","u9c7dc1e0ed7bdea8c7d2d72a779dd40a"]
myAdmin = ["u961d4fd88c0be4aa376b59ef89d4e3ab","u9c7dc1e0ed7bdea8c7d2d72a779dd40a"]
myAdmin = ["u961d4fd88c0be4aa376b59ef89d4e3ab"]
myAdmin2 = ["u961d4fd88c0be4aa376b59ef89d4e3ab"]
admin =["u961d4fd88c0be4aa376b59ef89d4e3ab"]


botStart = time.time()
msg_dict = {}
temp_flood = {}
groupName = {}
groupImage = {}
khiewuzz = {}
protectantijs = []
wbanlist = []
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
premium = json.load(premiumOpen)
java = json.load(javaOpen)
ingame = {
    "status": False,
    "msgWon": "الف مبروك لقد فزت @! \n للعب مره اخره ارسل ~{ الاسرع}"
    
    }

ingameOne = {
    "status": False,
    "msgWon": "الف مبروك لقد فزت @! \n للعب مره اخره ارسل ~{ حزوره}"
    
    }
hoho = {
    "savefile": False,
    "namefile": "",
}

add = {
    "addfriend": True,
}

asu = {
    "noteNjer": False,
}

peler = { 
    "receivercount": 0,
    "sendcount": 0
}

chatbot = {
    "admin": [],
    "botMute": [],
    "botOff": [],
}

join = {
    "autoJoin": True,
}

mcroom = {
    "leaveMc": True,
}

read = { 
    "readMember": {},
    "readPoint": {}
}

khiewuzz = {'mimic':{},'text1':'','text2':'','msgid': {},'token':'','thread':{},'exdrawing':False,'puzzle':False,'bathroom':False,'banksy':False,'romantic':False,'wanted':False,'DrawImage':False,'DrawMissing':{'t1':'','t2':'','t3':'','t4':False},'MakeMeme':False,'mimics': '','messageBOX': {},'listMessage':{},'talkblacklist':{'tos':{}},'unsendMessage':{}, 'replyChat':{}, 'mayhem': []}

khiewuzz1 = {
    "bansky": False,
    "bathroom": False,
    "exdrawing": False,
    "romantic": False,
    "puzzle": False,
    "wanted": False,
    "text1": "",
    "text2": "",
}

itil = {
    "blacklist": {},
}

wtf = {
    "autoBlock": False
}

mcroom = {
    "leaveMC": False,
}

selam = {
    "selam": False,
}


norak = {
    "detectTemplate": False,
}

nissa = {
    "addTikel2": {
        "name": "",
        "status": False
        },
}

tailah = {
    "siderTemp": {},
    "siderPesan": "•♥انضم واستمتع معي ♥•",
}

tailah1 = {
    "Rozi": {},
    "siderPesan": "انضم واستمتع معي•",
}

liffnya = {
        "ttt": "line://app/1602687308-GXq4Vvk9?type=text&text=",
}

anyun = {
    "addTikel": {
        "name": "",
        "status": False
        },
}

komen = {
    "komenan": False,
}

chatbot = {
    "admin": [],
    "botMute": [],
    "botOff": [],
}

tes = {
    "Message": {},
    "msg": {},
}

tes2 = {
    "Message2": {},
    "msg2": {},
}

peler = { 
    "receivercount": 0,
    "sendcount": 0
}

read = { 
    "readMember": {},
    "readPoint": {}
}

hoho = {
    "savefile": False,
    "namefile": "",
}

temptag = {
    "stealtag": False,
    "pesanya": "Yes dear , how can i help you",
}

itil = {
    "blacklist": {},
    "wblacklist": {},
    "whitelist": {},
    "wwhitelist": False,
    "dblacklist": False,
    "dwhitelist": False,
}

apalo = {
    "Talkblacklist": {},
    "Talkwblacklist": False,
    "Talkdblacklist": False,
    "talkban": True,
}

wmin = {
    "wMessage": False,
    "textnya": "Welcome To Family Group",
}
lvin = {
    "lMessage": False,
    "textnya": "Good bye Miss you 😭",
}

ProfileMe = {
    "myProfile": {
        "coverId": "",
        "pictureStatus": "",
        "statusMessage": ""
    },
    "PictureMe": "",
    "NameMe": "",
}
#=====================================================================
#=====================================================================
settings["myProfile"]["displayName"] = noobcoderProfile.displayName
settings["myProfile"]["statusMessage"] = noobcoderProfile.statusMessage
settings["myProfile"]["pictureStatus"] = noobcoderProfile.pictureStatus
cont = noobcoder.getContact(noobcoderMID)
settings["myProfile"]["videoProfile"] = cont.videoProfile
coverId = noobcoder.getProfileDetail()["result"]["objectId"]
settings["myProfile"]["coverId"] = coverId
myMid = noobcoder.getContact(noobcoderMID)
#=====================================================================
#=====================================================================
with open("noobcoder/temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("noobcoder/wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu
def debug():
    get_profile_time_start = time.time()
    get_profile = noobcoder.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_group_time_start = time.time()
    get_group = noobcoder.getGroupIdsJoined()
    get_group_time = time.time() - get_group_time_start
    get_contact_time_start = time.time()
    get_contact = noobcoder.getContact(get_profile.mid)
    get_contact_time = time.time() - get_contact_time_start
    elapsed_time = time.time() - get_profile_time_start
    return " 「 Debug 」\n - Send Message\n   %.5f\n - Get Profile\n   %.5f\n - Get Contact\n   %.5f\n - Get Group\n   %.5f" % (elapsed_time,get_profile_time,get_contact_time,get_group_time)
#=====================================================================
def powpow():
    Headers = {
    'User-Agent': "Line/8.9.1",
    'X-Line-Application': "CHROMEOS\t1.4.17\tChrome_OS\t1",
    "x-lal": "ja-US_US",
    }
    return Headers
#=====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
#=====================================================================
#=====================================================================
with open("temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu
#=====================================================================
# DEFF SPECIAL
def sendTemplate(group, data):
    warna1 = ("#00FFFF","#000000","#0000FF","#8A2BE2","#A52A2A","#7FFF00","#6495ED","#DC143C","#00FFFF","#00008B","#B8860B","#006400","#8B008B","#FF8C00","#FF8C00","#00CED1","#9400D3","#FF1493","#32CD32","#4B0082","#FF00FF","#0000CD","#48D1CC","#C71585","#000080","#FFA500","#FF4500","#FF0000")
    warnanya1 = random.choice(warna1)
    xyz = LiffChatContext(group)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendTemplate(to, data):
    warna1 = ("#00FFFF","#000000","#0000FF","#8A2BE2","#A52A2A","#7FFF00","#6495ED","#DC143C","#00FFFF","#00008B","#B8860B","#006400","#8B008B","#FF8C00","#FF8C00","#00CED1","#9400D3","#FF1493","#32CD32","#4B0082","#FF00FF","#0000CD","#48D1CC","#C71585","#000080","#FFA500","#FF4500","#FF0000")
    warnanya1 = random.choice(warna1)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def bcTemplate(gr, data):
    warna1 = ("#00FFFF","#000000","#0000FF","#8A2BE2","#A52A2A","#7FFF00","#6495ED","#DC143C","#00FFFF","#00008B","#B8860B","#006400","#8B008B","#FF8C00","#FF8C00","#00CED1","#9400D3","#FF1493","#32CD32","#4B0082","#FF00FF","#0000CD","#48D1CC","#C71585","#000080","#FFA500","#FF4500","#FF0000")
    warnanya1 = random.choice(warna1)
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def bcTemplate2(friend, data):
    warna1 = ("#00FFFF","#000000","#0000FF","#8A2BE2","#A52A2A","#7FFF00","#6495ED","#DC143C","#00FFFF","#00008B","#B8860B","#006400","#8B008B","#FF8C00","#FF8C00","#00CED1","#9400D3","#FF1493","#32CD32","#4B0082","#FF00FF","#0000CD","#48D1CC","#C71585","#000080","#FFA500","#FF4500","#FF0000")
    warnanya1 = random.choice(warna1)
    xyz = LiffChatContext(friend)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
#======================================================================
#def Template(to):
def sendMessageCustom(to, text, icon , name):
    annda = {'MSG_SENDER_ICON': icon,
        'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, text, contentMetadata=annda)
def sendMessageCustomContact(to, icon, name, mid):
    annda = { 'mid': mid,
    'MSG_SENDER_ICON': icon,
    'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, '', annda, 13)

def B64e(to, url):
	import base64
	return noobcoder.sendMessage(to, base64.b64encode(url.encode()).decode())

def B64d(to, url):
	import base64
	return noobcoder.sendMessage(to, base64.b64decode(url.encode()).decode())
	
def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact("u961d4fd88c0be4aa376b59ef89d4e3ab").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + noobcoder.getContact("u961d4fd88c0be4aa376b59ef89d4e3ab").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@PrncGang  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    noobcoder.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact("u961d4fd88c0be4aa376b59ef89d4e3ab").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = noobcoder.genOBSParams({'oid': noobcoderMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        noobcoder.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("noobcoderWasHere.mp4")
#=====================================================================
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)
        
def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()
	
def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        noobcoder.sendMessage(to, textx, {'MSG_SENDER_NAME': client.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def logError(text):
    noobcoder.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("noobcoder/errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
#=====================================================================
#=====================================================================
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
#=====================================================================
#=====================================================================
def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def backupData():
    try:
        backup = settings
        f = codecs.open('noobcoder/temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = wait
        f = codecs.open('noobcoder/wait.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = premium
        f = codecs.open('noobcoder/user.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = java
        f = codecs.open('noobcoder/java.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
#=====================================================================
#=====================================================================
async def noobcoderBot(op):
    try:
        if settings["restartPoint"] != None:
            noobcoder.sendMessage(settings["restartPoint"], 'Activated♪')
            settings["restartPoint"] = None
        if op.type == 0:
            return
                        
        if op.type in [22,24]:
            client.leaveRoom(op.param1)
#=====================================================================
        if op.type == 13:
            if noobcoder.getProfile().mid in op.param3:
                G = noobcoder.getCompactGroup(op.param1)
                if settings["autoJoin"] == True:
                    noobcoder.acceptGroupInvitation(op.param1)
                    mentions(op.param1,"Hallo @! Type  To see your command\nFor More Help 👇Contact👇",[op.param2])
                    noobcoder.sendMessage(op.param1, text=None, contentMetadata={'mid': "u961d4fd88c0be4aa376b59ef89d4e3ab"}, contentType=13)
        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message               
            text = msg.text
            msg_id = msg.id
            receiver = msg.to             
            sender = msg._from
            s = noobcoder.getProfile().mid
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False:
               setKey = ''
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:                    	
                    if sender != noobcoder.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if sender != s:
                	        peler["receivercount"] += 1
                        if sender == s:
                	        peler["sendcount"] += 1

        if op.type == 55:
            if op.param1 in tailah["siderTemp"] and op.param2 not in tailah["siderTemp"][op.param1]:
                tailah["siderTemp"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = noobcoder.getContact(op.param2)
                    cover = noobcoder.getProfileCoverURL(op.param2)
                    pesan = tailah["siderPesan"]
                    warna1 = ("#00FFFF","#000000","#0000FF","#8A2BE2","#A52A2A","#7FFF00","#6495ED","#DC143C","#00FFFF","#00008B","#B8860B","#006400","#8B008B","#FF8C00","#FF8C00","#00CED1","#9400D3","#FF1493","#32CD32","#4B0082","#FF00FF","#0000CD","#48D1CC","#C71585","#000080","#FFA500","#FF4500","#FF0000")
                    gifna = ("https://i.ibb.co/5vxHXFV/16-4284.jpg","https://i.ibb.co/FWjjZTf/b6ec73911a2a052bef5d8f30a00fadae.jpg","https://i.ibb.co/XxJDVTB/012b348156951b7dfbd1d894d480be6e.jpg","https://i.ibb.co/z56rSm3/images.jpg","https://i.ibb.co/m4DMWSt/5c5dce88a4a2f0c86ebfa49cd510fbd6.jpg","https://i.ibb.co/1n0ySjt/31112642-0.jpg")
                    warnanya1 = random.choice(warna1)
                    gifnay = random.choice(gifna)
                    data = {
                                  "type": "flex",
                                        "altText": "{}".format(noobcoder.getProfile().displayName),
                                        "contents": {
  "type": "bubble",
  "body": {
  "cornerRadius": "xl",
  "borderWidth": "4px",
  "borderColor": "#00FF00",
  "spacing": "sm",
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#00FF00",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "{}".format(str(contact.displayName)),
                            "weight": "bold",
                            "size": "md",
                            "color": "#FFFFFF",
                            "wrap": True
                          },
                          {
                            "text": "{}".format(pesan),
                            "size": "sm",
                            "align": "center",
                            "color": "#FFFFFF",
                            "wrap": True,
                            "weight": "regular",
                            "type": "text"
                            }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": warnanya1,
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                sendTemplate(op.param1, data)
                time.sleep(1)
                
        if op.type == 55:
            if op.param1 in tailah1["Rozi"] and op.param2 not in tailah1["Rozi"][op.param1]:
                tailah1["Rozi"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = noobcoder.getContact(op.param2)
                    cover = noobcoder.getProfileCoverURL(op.param2)
                    pesan = tailah1["siderPesan"]
                    warna1 = ("#00FFFF","#000000","#0000FF","#8A2BE2","#A52A2A","#7FFF00","#6495ED","#DC143C","#00FFFF","#00008B","#B8860B","#006400","#8B008B","#FF8C00","#FF8C00","#00CED1","#9400D3","#FF1493","#32CD32","#4B0082","#FF00FF","#0000CD","#48D1CC","#C71585","#000080","#FFA500","#FF4500","#FF0000")
                    gifna = ("https://i.ibb.co/5vxHXFV/16-4284.jpg","https://i.ibb.co/FWjjZTf/b6ec73911a2a052bef5d8f30a00fadae.jpg","https://i.ibb.co/XxJDVTB/012b348156951b7dfbd1d894d480be6e.jpg","https://i.ibb.co/z56rSm3/images.jpg","https://i.ibb.co/m4DMWSt/5c5dce88a4a2f0c86ebfa49cd510fbd6.jpg","https://i.ibb.co/1n0ySjt/31112642-0.jpg")
                    warnanya1 = random.choice(warna1)
                    gifnay = random.choice(gifna)
                    data = {
                        "type": "flex",
                        "altText": "{}".format(noobcoder.getProfile().displayName),
                        "contents": {
                            "type": "carousel",
                            "contents": [
                                {
                                    "type": "bubble",
                                    "size": "micro",
                                    "body": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                                "size": "full",
                                                "aspectMode": "cover",
                                                "aspectRatio": "2:3",
                                                "gravity": "top"
                                            },
                                            {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "{}".format(str(contact.displayName)),
                                                                "size": "sm",
                                                                "color": "#ffffff",
                                                                "weight": "bold"
                                                            }
                                                        ],
                                                        "offsetTop": "-50px"
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "baseline",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "{}".format(pesan),
                                                                "color": "#ffffff",
                                                                "size": "xs",
                                                                "flex": 0,
                                                                "wrap": True
                                                            }
                                                        ],
                                                        "spacing": "lg",
                                                        "offsetTop": "-50px"
                                                    }
                                                ],
                                                "position": "absolute",
                                                "offsetBottom": "0px",
                                                "offsetStart": "0px",
                                                "offsetEnd": "0px",
                                                "paddingAll": "20px",
                                                "paddingTop": "100px"
                                            },
                                            {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "Reader",
                                                        "color": "#ffffff",
                                                        "align": "center",
                                                        "size": "xs",
                                                        "offsetTop": "3px"
                                                    }
                                                ],
                                                "position": "absolute",
                                                "offsetTop": "18px",
                                                "backgroundColor": "#ff334b",
                                                "offsetStart": "18px",
                                                "height": "25px",
                                                "width": "53px",
                                                "cornerRadius": "5px"
                                            }
                                        ],
                                        "paddingAll": "0px",
                                        "cornerRadius": "12px",
                                        "borderWidth": "4px",
                                        "borderColor": "#FFFFFF"
                                    }
                                }
                            ]
                        }}
                    sendTemplate(op.param1, data)
                    

#=====================================================================
#==========================================
#==========================================
        if op.type in [22,24]:
            noobcoder.leaveRoom(op.param1)
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 6:
                    try:
                        contact = noobcoder.getContact(sender)
                        if msg.toType == 2:
                            anu = noobcoder.getGroup(to)
                            if msg.contentMetadata['GC_EVT_TYPE'] == 'S' and msg.contentMetadata['GC_MEDIA_TYPE'] == 'LIVE':
                                anu = msg.contentMetadata={'GC_EVT_TYPE': 'S', 'GC_CHAT_MID': to, 'RESULT': 'INFO', 'SKIP_BADGE_COUNT': 'false', 'GC_IGNORE_ON_FAILBACK': 'false', 'TYPE': 'G', 'DURATION': '0', 'GC_MEDIA_TYPE': 'VIDEO', 'VERSION': 'X', 'CAUSE': '16'}
                    except Exception as e:
                        noobcoder.sendMessage(to, str(e))

                if msg.contentType == 0:
                    if "/ti/g/" in text.lower():
                        if join["autoJoin"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = noobcoder.findGroupByTicket(ticket_id)
                                if len(group.members) >= wait["Members"]:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                else:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    noobcoder.leaveGroup(group.id)
                        
        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 16:
                    if msg._from in premium["myService"] or msg._from in ['u961d4fd88c0be4aa376b59ef89d4e3ab']:
                        if msg.toType in [2,1,0]:
                            try:
                                purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                                if purl[1] not in wait['postId']:
                                    noobcoder1.likePost(purl[0], purl[1], 1003)
                                    noobcoder2.likePost(purl[0], purl[1], 1003)
                                    noobcoder3.likePost(purl[0], purl[1], 1003)
                                    noobcoder4.likePost(purl[0], purl[1], 1003)
                                    noobcoder5.likePost(purl[0], purl[1], 1003)
                                    noobcoder6.likePost(purl[0], purl[1], 1003)
                                    noobcoder7.likePost(purl[0], purl[1], 1003)
                                    noobcoder8.likePost(purl[0], purl[1], 1003)
                                    noobcoder9.likePost(purl[0], purl[1], 1003)
                                    noobcoder10.likePost(purl[0], purl[1], 1003)
                                    noobcoder11.likePost(purl[0], purl[1], 1003)
                                    noobcoder12.likePost(purl[0], purl[1], 1003)
                                    noobcoder13.likePost(purl[0], purl[1], 1003)
                                    noobcoder14.likePost(purl[0], purl[1], 1003)
                                    noobcoder15.likePost(purl[0], purl[1], 1003)
                                    noobcoder16.likePost(purl[0], purl[1], 1003)
                                    noobcoder17.likePost(purl[0], purl[1], 1003)
                                    noobcoder18.likePost(purl[0], purl[1], 1003)
                                    noobcoder19.likePost(purl[0], purl[1], 1003)
                                    noobcoder20.likePost(purl[0], purl[1], 1003)
                                    noobcoder21.likePost(purl[0], purl[1], 1003)
                                    noobcoder22.likePost(purl[0], purl[1], 1003)
                                    noobcoder23.likePost(purl[0], purl[1], 1003)
                                    noobcoder24.likePost(purl[0], purl[1], 1003)
                                    noobcoder25.likePost(purl[0], purl[1], 1003)
                                    noobcoder26.likePost(purl[0], purl[1], 1003)
                                    noobcoder27.likePost(purl[0], purl[1], 1003)
                                    noobcoder28.likePost(purl[0], purl[1], 1003)
                                    noobcoder29.likePost(purl[0], purl[1], 1003)
                                    noobcoder30.likePost(purl[0], purl[1], 1003)
                                    noobcoder31.likePost(purl[0], purl[1], 1003)
                                    noobcoder32.likePost(purl[0], purl[1], 1003)
                                    noobcoder33.likePost(purl[0], purl[1], 1003)
                                    noobcoder34.likePost(purl[0], purl[1], 1003)
                                    noobcoder35.likePost(purl[0], purl[1], 1003)
                                    noobcoder36.likePost(purl[0], purl[1], 1003)
                                    noobcoder37.likePost(purl[0], purl[1], 1003)
                                    noobcoder38.likePost(purl[0], purl[1], 1003)
                                    noobcoder39.likePost(purl[0], purl[1], 1003)
                                    noobcoder40.likePost(purl[0], purl[1], 1003)
                                    noobcoder41.likePost(purl[0], purl[1], 1003)
                                    noobcoder42.likePost(purl[0], purl[1], 1003)
                                    noobcoder43.likePost(purl[0], purl[1], 1003)
                                    noobcoder44.likePost(purl[0], purl[1], 1003)
                                    noobcoder45.likePost(purl[0], purl[1], 1003)
                                    noobcoder46.likePost(purl[0], purl[1], 1003)
                                    noobcoder47.likePost(purl[0], purl[1], 1003)
                                    noobcoder48.likePost(purl[0], purl[1], 1003)
                                    noobcoder49.likePost(purl[0], purl[1], 1003)
                                    noobcoder50.likePost(purl[0], purl[1], 1003)
                                    noobcoder51.likePost(purl[0], purl[1], 1003)
                                    noobcoder52.likePost(purl[0], purl[1], 1003)
                                    noobcoder53.likePost(purl[0], purl[1], 1003)
                                    noobcoder54.likePost(purl[0], purl[1], 1003)
                                    noobcoder55.likePost(purl[0], purl[1], 1003)
                                    noobcoder56.likePost(purl[0], purl[1], 1003)
                                    noobcoder57.likePost(purl[0], purl[1], 1003)
                                    noobcoder58.likePost(purl[0], purl[1], 1003)
                                    noobcoder59.likePost(purl[0], purl[1], 1003)
                                    noobcoder60.likePost(purl[0], purl[1], 1003)
                                    noobcoder61.likePost(purl[0], purl[1], 1003)
                                    noobcoder62.likePost(purl[0], purl[1], 1003)
                                    noobcoder63.likePost(purl[0], purl[1], 1003)
                                    noobcoder64.likePost(purl[0], purl[1], 1003)
                                    noobcoder65.likePost(purl[0], purl[1], 1003)
                                    noobcoder66.likePost(purl[0], purl[1], 1003)
                                    noobcoder67.likePost(purl[0], purl[1], 1003)
                                    noobcoder68.likePost(purl[0], purl[1], 1003)
                                    noobcoder69.likePost(purl[0], purl[1], 1003)
                                    noobcoder70.likePost(purl[0], purl[1], 1003)
                                    noobcoder71.likePost(purl[0], purl[1], 1003)
                                    noobcoder72.likePost(purl[0], purl[1], 1003)
                                    noobcoder73.likePost(purl[0], purl[1], 1003)
                                    noobcoder74.likePost(purl[0], purl[1], 1003)
                                    noobcoder75.likePost(purl[0], purl[1], 1003)
                                    noobcoder76.likePost(purl[0], purl[1], 1003)
                                    noobcoder77.likePost(purl[0], purl[1], 1003)
                                    noobcoder78.likePost(purl[0], purl[1], 1003)
                                    noobcoder79.likePost(purl[0], purl[1], 1003)
                                    noobcoder80.likePost(purl[0], purl[1], 1003)
                                    noobcoder81.likePost(purl[0], purl[1], 1003)
                                    noobcoder82.likePost(purl[0], purl[1], 1003)
                                    noobcoder83.likePost(purl[0], purl[1], 1003)
                                    noobcoder84.likePost(purl[0], purl[1], 1003)
                                    noobcoder85.likePost(purl[0], purl[1], 1003)
                                    noobcoder86.likePost(purl[0], purl[1], 1003)
                                    noobcoder87.likePost(purl[0], purl[1], 1003)
                                    noobcoder88.likePost(purl[0], purl[1], 1003)
                                    noobcoder89.likePost(purl[0], purl[1], 1003)
                                    noobcoder90.likePost(purl[0], purl[1], 1003)
                                    noobcoder91.likePost(purl[0], purl[1], 1003)
                                    noobcoder92.likePost(purl[0], purl[1], 1003)
                                    noobcoder93.likePost(purl[0], purl[1], 1003)
                                    noobcoder94.likePost(purl[0], purl[1], 1003)
                                    noobcoder95.likePost(purl[0], purl[1], 1003)
                                    noobcoder96.likePost(purl[0], purl[1], 1003)
                                    noobcoder97.likePost(purl[0], purl[1], 1003)
                                    noobcoder98.likePost(purl[0], purl[1], 1003)
                                    noobcoder99.likePost(purl[0], purl[1], 1003)
                                    noobcoder100.likePost(purl[0], purl[1], 1003)
                                    noobcoder101.likePost(purl[0], purl[1], 1003)
                                    noobcoder102.likePost(purl[0], purl[1], 1003)
                                    noobcoder103.likePost(purl[0], purl[1], 1003)
                                    noobcoder104.likePost(purl[0], purl[1], 1003)
                                    noobcoder105.likePost(purl[0], purl[1], 1003)
                                    noobcoder106.likePost(purl[0], purl[1], 1003)
                                    noobcoder107.likePost(purl[0], purl[1], 1003)
                                    noobcoder108.likePost(purl[0], purl[1], 1003)
                                    noobcoder109.likePost(purl[0], purl[1], 1003)
                                    noobcoder110.likePost(purl[0], purl[1], 1003)
                                    noobcoder111.likePost(purl[0], purl[1], 1003)
                                    noobcoder112.likePost(purl[0], purl[1], 1003)
                                    noobcoder113.likePost(purl[0], purl[1], 1003)
                                    noobcoder114.likePost(purl[0], purl[1], 1003)
                                    noobcoder115.likePost(purl[0], purl[1], 1003)
                                    noobcoder116.likePost(purl[0], purl[1], 1003)
                                    noobcoder117.likePost(purl[0], purl[1], 1003)
                                    noobcoder118.likePost(purl[0], purl[1], 1003)
                                    noobcoder119.likePost(purl[0], purl[1], 1003)
                                    noobcoder120.likePost(purl[0], purl[1], 1003)
                                    noobcoder121.likePost(purl[0], purl[1], 1003)
                                    noobcoder122.likePost(purl[0], purl[1], 1003)
                                    noobcoder123.likePost(purl[0], purl[1], 1003)
                                    noobcoder124.likePost(purl[0], purl[1], 1003)
                                    noobcoder125.likePost(purl[0], purl[1], 1003)
                                    noobcoder126.likePost(purl[0], purl[1], 1003)
                                    noobcoder127.likePost(purl[0], purl[1], 1003)
                                    noobcoder128.likePost(purl[0], purl[1], 1003)
                                    noobcoder129.likePost(purl[0], purl[1], 1003)
                                    noobcoder130.likePost(purl[0], purl[1], 1003)
                                    noobcoder131.likePost(purl[0], purl[1], 1003)
                                    noobcoder132.likePost(purl[0], purl[1], 1003)
                                    noobcoder133.likePost(purl[0], purl[1], 1003)
                                    noobcoder134.likePost(purl[0], purl[1], 1003)
                                    noobcoder135.likePost(purl[0], purl[1], 1003)
                                    noobcoder136.likePost(purl[0], purl[1], 1003)
                                    noobcoder137.likePost(purl[0], purl[1], 1003)
                                    noobcoder138.likePost(purl[0], purl[1], 1003)
                                    noobcoder139.likePost(purl[0], purl[1], 1003)
                                    noobcoder140.likePost(purl[0], purl[1], 1003)
                                    noobcoder141.likePost(purl[0], purl[1], 1003)
                                    noobcoder142.likePost(purl[0], purl[1], 1003)
                                    noobcoder143.likePost(purl[0], purl[1], 1003)
                                    noobcoder144.likePost(purl[0], purl[1], 1003)
                                    noobcoder145.likePost(purl[0], purl[1], 1003)
                                    noobcoder146.likePost(purl[0], purl[1], 1003)
                                    noobcoder147.likePost(purl[0], purl[1], 1003)
                                    noobcoder148.likePost(purl[0], purl[1], 1003)
                                    noobcoder149.likePost(purl[0], purl[1], 1003)
                                    noobcoder150.likePost(purl[0], purl[1], 1003)
                                    noobcoder151.likePost(purl[0], purl[1], 1003)
                                    noobcoder152.likePost(purl[0], purl[1], 1003)
                                    noobcoder153.likePost(purl[0], purl[1], 1003)
                                    noobcoder154.likePost(purl[0], purl[1], 1003)
                                    noobcoder155.likePost(purl[0], purl[1], 1003)
                                    noobcoder156.likePost(purl[0], purl[1], 1003)
                                    noobcoder157.likePost(purl[0], purl[1], 1003)
                                    noobcoder158.likePost(purl[0], purl[1], 1003)
                                    noobcoder159.likePost(purl[0], purl[1], 1003)
                                    noobcoder160.likePost(purl[0], purl[1], 1003)
                                    noobcoder161.likePost(purl[0], purl[1], 1003)
                                    noobcoder162.likePost(purl[0], purl[1], 1003)
                                    noobcoder163.likePost(purl[0], purl[1], 1003)
                                    noobcoder164.likePost(purl[0], purl[1], 1003)
                                    noobcoder165.likePost(purl[0], purl[1], 1003)
                                    noobcoder166.likePost(purl[0], purl[1], 1003)
                                    noobcoder167.likePost(purl[0], purl[1], 1003)
                                    noobcoder168.likePost(purl[0], purl[1], 1003)
                                    noobcoder169.likePost(purl[0], purl[1], 1003)
                                    noobcoder170.likePost(purl[0], purl[1], 1003)
                                    noobcoder171.likePost(purl[0], purl[1], 1003)
                                    noobcoder172.likePost(purl[0], purl[1], 1003)
                                    noobcoder173.likePost(purl[0], purl[1], 1003)
                                    noobcoder174.likePost(purl[0], purl[1], 1003)
                                    noobcoder175.likePost(purl[0], purl[1], 1003)
                                    noobcoder176.likePost(purl[0], purl[1], 1003)
                                    noobcoder177.likePost(purl[0], purl[1], 1003)
                                    noobcoder178.likePost(purl[0], purl[1], 1003)
                                    noobcoder179.likePost(purl[0], purl[1], 1003)
                                    noobcoder180.likePost(purl[0], purl[1], 1003)
                                    noobcoder181.likePost(purl[0], purl[1], 1003)
                                    noobcoder182.likePost(purl[0], purl[1], 1003)
                                    noobcoder183.likePost(purl[0], purl[1], 1003)
                                    noobcoder184.likePost(purl[0], purl[1], 1003)
                                    noobcoder185.likePost(purl[0], purl[1], 1003)
                                    noobcoder186.likePost(purl[0], purl[1], 1003)
                                    noobcoder187.likePost(purl[0], purl[1], 1003)
                                    noobcoder188.likePost(purl[0], purl[1], 1003)
                                    noobcoder189.likePost(purl[0], purl[1], 1003)
                                    noobcoder190.likePost(purl[0], purl[1], 1003)
                                    noobcoder191.likePost(purl[0], purl[1], 1003)
                                    noobcoder192.likePost(purl[0], purl[1], 1003)
                                    noobcoder193.likePost(purl[0], purl[1], 1003)
                                    noobcoder194.likePost(purl[0], purl[1], 1003)
                                    noobcoder195.likePost(purl[0], purl[1], 1003)
                                    noobcoder196.likePost(purl[0], purl[1], 1003)
                                    noobcoder197.likePost(purl[0], purl[1], 1003)
                                    noobcoder198.likePost(purl[0], purl[1], 1003)
                                    noobcoder199.likePost(purl[0], purl[1], 1003)
                                    noobcoder200.likePost(purl[0], purl[1], 1003)
                                    noobcoder.sendMessage(to, "Your post has been liked")
                                    noobcoder.createComment(purl[0], purl[1],"AutoLike \n\nContact Person:\nhttp://line.me/ti/p/~arhaby")
                                    wait['postId'].append(purl[1])
                                else:
                                    pass
                            except Exception as e:
                                purl = msg.contentMetadata['postEndUrl'].split('homeId=')[1].split('&postId=')
                                if purl[1] not in wait['postId']:
                                    noobcoder1.likePost(purl[0], purl[1], 1003)
                                    noobcoder2.likePost(purl[0], purl[1], 1003)
                                    noobcoder3.likePost(purl[0], purl[1], 1003)
                                    noobcoder4.likePost(purl[0], purl[1], 1003)
                                    noobcoder5.likePost(purl[0], purl[1], 1003)
                                    noobcoder6.likePost(purl[0], purl[1], 1003)
                                    noobcoder7.likePost(purl[0], purl[1], 1003)
                                    noobcoder8.likePost(purl[0], purl[1], 1003)
                                    noobcoder9.likePost(purl[0], purl[1], 1003)
                                    noobcoder10.likePost(purl[0], purl[1], 1003)
                                    noobcoder11.likePost(purl[0], purl[1], 1003)
                                    noobcoder12.likePost(purl[0], purl[1], 1003)
                                    noobcoder13.likePost(purl[0], purl[1], 1003)
                                    noobcoder14.likePost(purl[0], purl[1], 1003)
                                    noobcoder15.likePost(purl[0], purl[1], 1003)
                                    noobcoder16.likePost(purl[0], purl[1], 1003)
                                    noobcoder17.likePost(purl[0], purl[1], 1003)
                                    noobcoder18.likePost(purl[0], purl[1], 1003)
                                    noobcoder19.likePost(purl[0], purl[1], 1003)
                                    noobcoder20.likePost(purl[0], purl[1], 1003)
                                    noobcoder21.likePost(purl[0], purl[1], 1003)
                                    noobcoder22.likePost(purl[0], purl[1], 1003)
                                    noobcoder23.likePost(purl[0], purl[1], 1003)
                                    noobcoder24.likePost(purl[0], purl[1], 1003)
                                    noobcoder25.likePost(purl[0], purl[1], 1003)
                                    noobcoder26.likePost(purl[0], purl[1], 1003)
                                    noobcoder27.likePost(purl[0], purl[1], 1003)
                                    noobcoder28.likePost(purl[0], purl[1], 1003)
                                    noobcoder29.likePost(purl[0], purl[1], 1003)
                                    noobcoder30.likePost(purl[0], purl[1], 1003)
                                    noobcoder31.likePost(purl[0], purl[1], 1003)
                                    noobcoder32.likePost(purl[0], purl[1], 1003)
                                    noobcoder33.likePost(purl[0], purl[1], 1003)
                                    noobcoder34.likePost(purl[0], purl[1], 1003)
                                    noobcoder35.likePost(purl[0], purl[1], 1003)
                                    noobcoder36.likePost(purl[0], purl[1], 1003)
                                    noobcoder37.likePost(purl[0], purl[1], 1003)
                                    noobcoder38.likePost(purl[0], purl[1], 1003)
                                    noobcoder39.likePost(purl[0], purl[1], 1003)
                                    noobcoder40.likePost(purl[0], purl[1], 1003)
                                    noobcoder41.likePost(purl[0], purl[1], 1003)
                                    noobcoder42.likePost(purl[0], purl[1], 1003)
                                    noobcoder43.likePost(purl[0], purl[1], 1003)
                                    noobcoder44.likePost(purl[0], purl[1], 1003)
                                    noobcoder45.likePost(purl[0], purl[1], 1003)
                                    noobcoder46.likePost(purl[0], purl[1], 1003)
                                    noobcoder47.likePost(purl[0], purl[1], 1003)
                                    noobcoder48.likePost(purl[0], purl[1], 1003)
                                    noobcoder49.likePost(purl[0], purl[1], 1003)
                                    noobcoder50.likePost(purl[0], purl[1], 1003)
                                    noobcoder51.likePost(purl[0], purl[1], 1003)
                                    noobcoder52.likePost(purl[0], purl[1], 1003)
                                    noobcoder53.likePost(purl[0], purl[1], 1003)
                                    noobcoder54.likePost(purl[0], purl[1], 1003)
                                    noobcoder55.likePost(purl[0], purl[1], 1003)
                                    noobcoder56.likePost(purl[0], purl[1], 1003)
                                    noobcoder57.likePost(purl[0], purl[1], 1003)
                                    noobcoder58.likePost(purl[0], purl[1], 1003)
                                    noobcoder59.likePost(purl[0], purl[1], 1003)
                                    noobcoder60.likePost(purl[0], purl[1], 1003)
                                    noobcoder61.likePost(purl[0], purl[1], 1003)
                                    noobcoder62.likePost(purl[0], purl[1], 1003)
                                    noobcoder63.likePost(purl[0], purl[1], 1003)
                                    noobcoder64.likePost(purl[0], purl[1], 1003)
                                    noobcoder65.likePost(purl[0], purl[1], 1003)
                                    noobcoder66.likePost(purl[0], purl[1], 1003)
                                    noobcoder67.likePost(purl[0], purl[1], 1003)
                                    noobcoder68.likePost(purl[0], purl[1], 1003)
                                    noobcoder69.likePost(purl[0], purl[1], 1003)
                                    noobcoder70.likePost(purl[0], purl[1], 1003)
                                    noobcoder71.likePost(purl[0], purl[1], 1003)
                                    noobcoder72.likePost(purl[0], purl[1], 1003)
                                    noobcoder73.likePost(purl[0], purl[1], 1003)
                                    noobcoder74.likePost(purl[0], purl[1], 1003)
                                    noobcoder75.likePost(purl[0], purl[1], 1003)
                                    noobcoder76.likePost(purl[0], purl[1], 1003)
                                    noobcoder77.likePost(purl[0], purl[1], 1003)
                                    noobcoder78.likePost(purl[0], purl[1], 1003)
                                    noobcoder79.likePost(purl[0], purl[1], 1003)
                                    noobcoder80.likePost(purl[0], purl[1], 1003)
                                    noobcoder81.likePost(purl[0], purl[1], 1003)
                                    noobcoder82.likePost(purl[0], purl[1], 1003)
                                    noobcoder83.likePost(purl[0], purl[1], 1003)
                                    noobcoder84.likePost(purl[0], purl[1], 1003)
                                    noobcoder85.likePost(purl[0], purl[1], 1003)
                                    noobcoder86.likePost(purl[0], purl[1], 1003)
                                    noobcoder87.likePost(purl[0], purl[1], 1003)
                                    noobcoder88.likePost(purl[0], purl[1], 1003)
                                    noobcoder89.likePost(purl[0], purl[1], 1003)
                                    noobcoder90.likePost(purl[0], purl[1], 1003)
                                    noobcoder91.likePost(purl[0], purl[1], 1003)
                                    noobcoder92.likePost(purl[0], purl[1], 1003)
                                    noobcoder93.likePost(purl[0], purl[1], 1003)
                                    noobcoder94.likePost(purl[0], purl[1], 1003)
                                    noobcoder95.likePost(purl[0], purl[1], 1003)
                                    noobcoder96.likePost(purl[0], purl[1], 1003)
                                    noobcoder97.likePost(purl[0], purl[1], 1003)
                                    noobcoder98.likePost(purl[0], purl[1], 1003)
                                    noobcoder99.likePost(purl[0], purl[1], 1003)
                                    noobcoder100.likePost(purl[0], purl[1], 1003)
                                    noobcoder101.likePost(purl[0], purl[1], 1003)
                                    noobcoder102.likePost(purl[0], purl[1], 1003)
                                    noobcoder103.likePost(purl[0], purl[1], 1003)
                                    noobcoder104.likePost(purl[0], purl[1], 1003)
                                    noobcoder105.likePost(purl[0], purl[1], 1003)
                                    noobcoder106.likePost(purl[0], purl[1], 1003)
                                    noobcoder107.likePost(purl[0], purl[1], 1003)
                                    noobcoder108.likePost(purl[0], purl[1], 1003)
                                    noobcoder109.likePost(purl[0], purl[1], 1003)
                                    noobcoder110.likePost(purl[0], purl[1], 1003)
                                    noobcoder111.likePost(purl[0], purl[1], 1003)
                                    noobcoder112.likePost(purl[0], purl[1], 1003)
                                    noobcoder113.likePost(purl[0], purl[1], 1003)
                                    noobcoder114.likePost(purl[0], purl[1], 1003)
                                    noobcoder115.likePost(purl[0], purl[1], 1003)
                                    noobcoder116.likePost(purl[0], purl[1], 1003)
                                    noobcoder117.likePost(purl[0], purl[1], 1003)
                                    noobcoder118.likePost(purl[0], purl[1], 1003)
                                    noobcoder119.likePost(purl[0], purl[1], 1003)
                                    noobcoder120.likePost(purl[0], purl[1], 1003)
                                    noobcoder121.likePost(purl[0], purl[1], 1003)
                                    noobcoder122.likePost(purl[0], purl[1], 1003)
                                    noobcoder123.likePost(purl[0], purl[1], 1003)
                                    noobcoder124.likePost(purl[0], purl[1], 1003)
                                    noobcoder125.likePost(purl[0], purl[1], 1003)
                                    noobcoder126.likePost(purl[0], purl[1], 1003)
                                    noobcoder127.likePost(purl[0], purl[1], 1003)
                                    noobcoder128.likePost(purl[0], purl[1], 1003)
                                    noobcoder129.likePost(purl[0], purl[1], 1003)
                                    noobcoder130.likePost(purl[0], purl[1], 1003)
                                    noobcoder131.likePost(purl[0], purl[1], 1003)
                                    noobcoder132.likePost(purl[0], purl[1], 1003)
                                    noobcoder133.likePost(purl[0], purl[1], 1003)
                                    noobcoder134.likePost(purl[0], purl[1], 1003)
                                    noobcoder135.likePost(purl[0], purl[1], 1003)
                                    noobcoder136.likePost(purl[0], purl[1], 1003)
                                    noobcoder137.likePost(purl[0], purl[1], 1003)
                                    noobcoder138.likePost(purl[0], purl[1], 1003)
                                    noobcoder139.likePost(purl[0], purl[1], 1003)
                                    noobcoder140.likePost(purl[0], purl[1], 1003)
                                    noobcoder141.likePost(purl[0], purl[1], 1003)
                                    noobcoder142.likePost(purl[0], purl[1], 1003)
                                    noobcoder143.likePost(purl[0], purl[1], 1003)
                                    noobcoder144.likePost(purl[0], purl[1], 1003)
                                    noobcoder145.likePost(purl[0], purl[1], 1003)
                                    noobcoder146.likePost(purl[0], purl[1], 1003)
                                    noobcoder147.likePost(purl[0], purl[1], 1003)
                                    noobcoder148.likePost(purl[0], purl[1], 1003)
                                    noobcoder149.likePost(purl[0], purl[1], 1003)
                                    noobcoder150.likePost(purl[0], purl[1], 1003)
                                    noobcoder151.likePost(purl[0], purl[1], 1003)
                                    noobcoder152.likePost(purl[0], purl[1], 1003)
                                    noobcoder153.likePost(purl[0], purl[1], 1003)
                                    noobcoder154.likePost(purl[0], purl[1], 1003)
                                    noobcoder155.likePost(purl[0], purl[1], 1003)
                                    noobcoder156.likePost(purl[0], purl[1], 1003)
                                    noobcoder157.likePost(purl[0], purl[1], 1003)
                                    noobcoder158.likePost(purl[0], purl[1], 1003)
                                    noobcoder159.likePost(purl[0], purl[1], 1003)
                                    noobcoder160.likePost(purl[0], purl[1], 1003)
                                    noobcoder161.likePost(purl[0], purl[1], 1003)
                                    noobcoder162.likePost(purl[0], purl[1], 1003)
                                    noobcoder163.likePost(purl[0], purl[1], 1003)
                                    noobcoder164.likePost(purl[0], purl[1], 1003)
                                    noobcoder165.likePost(purl[0], purl[1], 1003)
                                    noobcoder166.likePost(purl[0], purl[1], 1003)
                                    noobcoder167.likePost(purl[0], purl[1], 1003)
                                    noobcoder168.likePost(purl[0], purl[1], 1003)
                                    noobcoder169.likePost(purl[0], purl[1], 1003)
                                    noobcoder170.likePost(purl[0], purl[1], 1003)
                                    noobcoder171.likePost(purl[0], purl[1], 1003)
                                    noobcoder172.likePost(purl[0], purl[1], 1003)
                                    noobcoder173.likePost(purl[0], purl[1], 1003)
                                    noobcoder174.likePost(purl[0], purl[1], 1003)
                                    noobcoder175.likePost(purl[0], purl[1], 1003)
                                    noobcoder176.likePost(purl[0], purl[1], 1003)
                                    noobcoder177.likePost(purl[0], purl[1], 1003)
                                    noobcoder178.likePost(purl[0], purl[1], 1003)
                                    noobcoder179.likePost(purl[0], purl[1], 1003)
                                    noobcoder180.likePost(purl[0], purl[1], 1003)
                                    noobcoder181.likePost(purl[0], purl[1], 1003)
                                    noobcoder182.likePost(purl[0], purl[1], 1003)
                                    noobcoder183.likePost(purl[0], purl[1], 1003)
                                    noobcoder184.likePost(purl[0], purl[1], 1003)
                                    noobcoder185.likePost(purl[0], purl[1], 1003)
                                    noobcoder186.likePost(purl[0], purl[1], 1003)
                                    noobcoder187.likePost(purl[0], purl[1], 1003)
                                    noobcoder188.likePost(purl[0], purl[1], 1003)
                                    noobcoder189.likePost(purl[0], purl[1], 1003)
                                    noobcoder190.likePost(purl[0], purl[1], 1003)
                                    noobcoder191.likePost(purl[0], purl[1], 1003)
                                    noobcoder192.likePost(purl[0], purl[1], 1003)
                                    noobcoder193.likePost(purl[0], purl[1], 1003)
                                    noobcoder194.likePost(purl[0], purl[1], 1003)
                                    noobcoder195.likePost(purl[0], purl[1], 1003)
                                    noobcoder196.likePost(purl[0], purl[1], 1003)
                                    noobcoder197.likePost(purl[0], purl[1], 1003)
                                    noobcoder198.likePost(purl[0], purl[1], 1003)
                                    noobcoder199.likePost(purl[0], purl[1], 1003)
                                    noobcoder200.likePost(purl[0], purl[1], 1003)
                                    noobcoder.sendMessage(to, "Your post has been liked")
                                    noobcoder.createComment(purl[0], purl[1],"AutoLike ?\n\nContact Person:\nhttp://line.me/ti/p/~arhaby")
                                    wait['postId'].append(purl[1])
                                else:pass

        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 16:
                    if msg._from in premium["myService"]:
                        if msg.toType in [2,1,0]:
                            try:
                                purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                                if purl[1] not in wait['postId']:
                                	time.sleep(0.1)
                                	noobcoder.sendMessage(to, "Your post is being processed for liked\n\nNOTICE : Don't send another post when the bots are doing an unfinished like")
                                else:
                                    pass
                            except Exception as e:
                                purl = msg.contentMetadata['postEndUrl'].split('homeId=')[1].split('&postId=')
                                if purl[1] not in wait['postId']:
                                    noobcoder.sendMessage(to, "Your post has been liked")
                                else:pass

        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 13:
                    if add["addfriend"] == True:
                        wonge = msg.contentMetadata["mid"]
                        noobcoder.findAndAddContactsByMid(wonge)
                        add["addfriend"] = False
                if msg.contentType == 14:
                    if hoho["savefile"] == True:
                        try:
                             namafile = hoho["namafile"]
                             noobcoder.downloadObjectMsg(msg_id,saveAs=namafile)
                             hoho["savefile"] = False
                             noobcoder.sendMessage(to, "Successful, the file has been uploaded")
                        except Exception as e:
                         	noobcoder.sendMessage(to, str(e))
                if msg.contentType == 1:
                    if settings["changePicture"] == True:
                        path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        settings["changePicture"] = False
                        noobcoder.updateProfilePicture(path)
                        noobcoder.sendMessage(to,"Profile Image Updated.")
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if settings["autoRead"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if settings["autoRead1"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
#==========================================
                    if cmd == "threads":
                        noobcoder.sendMessage(to,'Threads: {}'.format(threading.active_count()))
                        log.info("Debug Threads.")                            
                    elif cmd.startswith("#savefile"):
                        if msg._from in myAdmin:
                            text = removeCmd("#savefile", text)
                            sep = text.split(" ")
                            key = text.replace(sep[0] + " ", text)
                            if " " in key:
                                noobcoder.sendMessage(to, "Failed !")
                            else:
                                hoho["namafile"] = str(key).lower()
                                hoho["savefile"] = True
                                noobcoder.sendMessage(to, "Send file to save to be「 {} 」".format(str(key).lower()))
                    elif cmd.startswith("exec"):
                        if msg._from in myAdmin:
                            try:
                                sep = text.split("\n")
                                txt = text.replace(sep[0] + "\n","")
                                exec(txt)
                            except:
                                pass
                    if cmd == "likemypost":
                        if msg._from in myAdmin or msg._from in['u961d4fd88c0be4aa376b59ef89d4e3ab']:
                            try:
                                a = noobcoder.getHomeProfile(msg._from)
                                for i in a['result']['feeds']:
                                    b = i['post']['postInfo']['postId']
                                    c = i['post']['userInfo']['mid']
                                    if b not in wait["postId"]:
                                        noobcoder.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder1.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder2.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder3.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder4.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder5.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder6.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder7.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder8.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder9.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder10.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder11.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder12.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder13.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder14.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder15.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder16.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder17.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder18.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder19.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder20.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder21.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder22.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder23.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder24.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder25.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder26.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder27.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder28.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder29.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder30.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder31.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder32.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder33.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder34.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder35.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder36.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder37.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder38.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder39.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder40.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder41.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder42.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder43.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder44.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder45.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder46.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder47.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder48.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder49.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder50.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder51.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder52.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder53.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder54.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder55.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder56.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder57.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder58.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder59.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder60.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder61.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder62.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder63.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder64.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder65.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder66.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder67.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder68.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder69.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder70.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder71.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder72.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder73.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder74.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder75.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder76.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder77.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder78.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder79.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder80.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder81.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder82.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder83.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder84.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder85.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder86.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder87.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder88.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder89.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder90.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder91.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder92.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder93.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder94.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder95.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder96.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder97.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder98.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder99.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder100.likePost(c,b,random.choice([1001,1002]))
                                        noobcoder.createComment(c,b,"كلوثر تتمشى")
                                        wait["postId"].append(b)
                                    else:pass
                                noobcoder.sendMessage(to, "Like done..")
                            except Exception as e:
                                noobcoder.sendMessage(to, "Tidak ada post yg harus dilike")
                    elif cmd == "cpp" :
                        if msg._from in myAdmin:
                            settings["changePicture"] = True
                            noobcoder.sendMessage(to, "Send a Image to change picture.")
                    elif cmd == "tes":
                        if msg._from in myAdmin:
                            noobcoder1.removeAllMessages(op.param2)
                            noobcoder2.removeAllMessages(op.param2)
                            noobcoder3.removeAllMessages(op.param2)
                            noobcoder4.removeAllMessages(op.param2)
                            noobcoder5.removeAllMessages(op.param2)
                            noobcoder6.removeAllMessages(op.param2)
                            noobcoder7.removeAllMessages(op.param2)
                            noobcoder8.removeAllMessages(op.param2)
                            noobcoder9.removeAllMessages(op.param2)
                            noobcoder10.removeAllMessages(op.param2)
                            noobcoder11.removeAllMessages(op.param2)
                            noobcoder12.removeAllMessages(op.param2)
                            noobcoder13.removeAllMessages(op.param2)
                            noobcoder14.removeAllMessages(op.param2)
                            noobcoder15.removeAllMessages(op.param2)
                            noobcoder16.removeAllMessages(op.param2)
                            noobcoder17.removeAllMessages(op.param2)
                            noobcoder18.removeAllMessages(op.param2)
                            noobcoder19.removeAllMessages(op.param2)
                            noobcoder20.removeAllMessages(op.param2)
                            noobcoder21.removeAllMessages(op.param2)
                            noobcoder22.removeAllMessages(op.param2)
                            noobcoder23.removeAllMessages(op.param2)
                            noobcoder24.removeAllMessages(op.param2)
                            noobcoder25.removeAllMessages(op.param2)
                            noobcoder26.removeAllMessages(op.param2)
                            noobcoder27.removeAllMessages(op.param2)
                            noobcoder28.removeAllMessages(op.param2)
                            noobcoder29.removeAllMessages(op.param2)
                            noobcoder30.removeAllMessages(op.param2)
                            noobcoder31.removeAllMessages(op.param2)
                            noobcoder32.removeAllMessages(op.param2)
                            noobcoder33.removeAllMessages(op.param2)
                            noobcoder34.removeAllMessages(op.param2)
                            noobcoder35.removeAllMessages(op.param2)
                            noobcoder36.removeAllMessages(op.param2)
                            noobcoder37.removeAllMessages(op.param2)
                            noobcoder38.removeAllMessages(op.param2)
                            noobcoder39.removeAllMessages(op.param2)
                            noobcoder40.removeAllMessages(op.param2)
                            noobcoder41.removeAllMessages(op.param2)
                            noobcoder42.removeAllMessages(op.param2)
                            noobcoder43.removeAllMessages(op.param2)
                            noobcoder44.removeAllMessages(op.param2)
                            noobcoder45.removeAllMessages(op.param2)
                            noobcoder46.removeAllMessages(op.param2)
                            noobcoder47.removeAllMessages(op.param2)
                            noobcoder48.removeAllMessages(op.param2)
                            noobcoder49.removeAllMessages(op.param2)
                            noobcoder50.removeAllMessages(op.param2)
                            noobcoder51.removeAllMessages(op.param2)
                            noobcoder52.removeAllMessages(op.param2)
                            noobcoder53.removeAllMessages(op.param2)
                            noobcoder54.removeAllMessages(op.param2)
                            noobcoder55.removeAllMessages(op.param2)
                            noobcoder56.removeAllMessages(op.param2)
                            noobcoder57.removeAllMessages(op.param2)
                            noobcoder58.removeAllMessages(op.param2)
                            noobcoder59.removeAllMessages(op.param2)
                            noobcoder60.removeAllMessages(op.param2)
                            noobcoder61.removeAllMessages(op.param2)
                            noobcoder62.removeAllMessages(op.param2)
                            noobcoder63.removeAllMessages(op.param2)
                            noobcoder64.removeAllMessages(op.param2)
                            noobcoder65.removeAllMessages(op.param2)
                            noobcoder66.removeAllMessages(op.param2)
                            noobcoder67.removeAllMessages(op.param2)
                            noobcoder68.removeAllMessages(op.param2)
                            noobcoder69.removeAllMessages(op.param2)
                            noobcoder70.removeAllMessages(op.param2)
                            noobcoder71.removeAllMessages(op.param2)
                            noobcoder72.removeAllMessages(op.param2)
                            noobcoder73.removeAllMessages(op.param2)
                            noobcoder74.removeAllMessages(op.param2)
                            noobcoder75.removeAllMessages(op.param2)
                            noobcoder76.removeAllMessages(op.param2)
                            noobcoder77.removeAllMessages(op.param2)
                            noobcoder78.removeAllMessages(op.param2)
                            noobcoder79.removeAllMessages(op.param2)
                            noobcoder80.removeAllMessages(op.param2)
                            noobcoder81.removeAllMessages(op.param2)
                            noobcoder82.removeAllMessages(op.param2)
                            noobcoder83.removeAllMessages(op.param2)
                            noobcoder84.removeAllMessages(op.param2)
                            noobcoder85.removeAllMessages(op.param2)
                            noobcoder86.removeAllMessages(op.param2)
                            noobcoder87.removeAllMessages(op.param2)
                            noobcoder88.removeAllMessages(op.param2)
                            noobcoder89.removeAllMessages(op.param2)
                            noobcoder90.removeAllMessages(op.param2)
                            noobcoder91.removeAllMessages(op.param2)
                            noobcoder92.removeAllMessages(op.param2)
                            noobcoder93.removeAllMessages(op.param2)
                            noobcoder94.removeAllMessages(op.param2)
                            noobcoder95.removeAllMessages(op.param2)
                            noobcoder96.removeAllMessages(op.param2)
                            noobcoder97.removeAllMessages(op.param2)
                            noobcoder98.removeAllMessages(op.param2)
                            noobcoder99.removeAllMessages(op.param2)
                            noobcoder100.removeAllMessages(op.param2)
                            noobcoder101.removeAllMessages(op.param2)
                            noobcoder102.removeAllMessages(op.param2)
                            noobcoder103.removeAllMessages(op.param2)
                            noobcoder104.removeAllMessages(op.param2)
                            noobcoder105.removeAllMessages(op.param2)
                            noobcoder106.removeAllMessages(op.param2)
                            noobcoder107.removeAllMessages(op.param2)
                            noobcoder108.removeAllMessages(op.param2)
                            noobcoder109.removeAllMessages(op.param2)
                            noobcoder110.removeAllMessages(op.param2)
                            noobcoder111.removeAllMessages(op.param2)
                            noobcoder112.removeAllMessages(op.param2)
                            noobcoder113.removeAllMessages(op.param2)
                            noobcoder114.removeAllMessages(op.param2)
                            noobcoder115.removeAllMessages(op.param2)
                            noobcoder116.removeAllMessages(op.param2)
                            noobcoder117.removeAllMessages(op.param2)
                            noobcoder118.removeAllMessages(op.param2)
                            noobcoder119.removeAllMessages(op.param2)
                            noobcoder120.removeAllMessages(op.param2)
                            noobcoder121.removeAllMessages(op.param2)
                            noobcoder122.removeAllMessages(op.param2)
                            noobcoder123.removeAllMessages(op.param2)
                            noobcoder124.removeAllMessages(op.param2)
                            noobcoder125.removeAllMessages(op.param2)
                            noobcoder126.removeAllMessages(op.param2)
                            noobcoder127.removeAllMessages(op.param2)
                            noobcoder128.removeAllMessages(op.param2)
                            noobcoder129.removeAllMessages(op.param2)
                            noobcoder130.removeAllMessages(op.param2)
                            noobcoder131.removeAllMessages(op.param2)
                            noobcoder132.removeAllMessages(op.param2)
                            noobcoder133.removeAllMessages(op.param2)
                            noobcoder134.removeAllMessages(op.param2)
                            noobcoder135.removeAllMessages(op.param2)
                            noobcoder136.removeAllMessages(op.param2)
                            noobcoder137.removeAllMessages(op.param2)
                            noobcoder138.removeAllMessages(op.param2)
                            noobcoder139.removeAllMessages(op.param2)
                            noobcoder140.removeAllMessages(op.param2)
                            noobcoder141.removeAllMessages(op.param2)
                            noobcoder142.removeAllMessages(op.param2)
                            noobcoder143.removeAllMessages(op.param2)
                            noobcoder144.removeAllMessages(op.param2)
                            noobcoder145.removeAllMessages(op.param2)
                            noobcoder146.removeAllMessages(op.param2)
                            noobcoder147.removeAllMessages(op.param2)
                            noobcoder148.removeAllMessages(op.param2)
                            noobcoder149.removeAllMessages(op.param2)
                            noobcoder150.removeAllMessages(op.param2)
                            noobcoder151.removeAllMessages(op.param2)
                            noobcoder152.removeAllMessages(op.param2)
                            noobcoder153.removeAllMessages(op.param2)
                            noobcoder154.removeAllMessages(op.param2)
                            noobcoder155.removeAllMessages(op.param2)
                            noobcoder156.removeAllMessages(op.param2)
                            noobcoder157.removeAllMessages(op.param2)
                            noobcoder158.removeAllMessages(op.param2)
                            noobcoder159.removeAllMessages(op.param2)
                            noobcoder160.removeAllMessages(op.param2)
                            noobcoder161.removeAllMessages(op.param2)
                            noobcoder162.removeAllMessages(op.param2)
                            noobcoder163.removeAllMessages(op.param2)
                            noobcoder164.removeAllMessages(op.param2)
                            noobcoder165.removeAllMessages(op.param2)
                            noobcoder166.removeAllMessages(op.param2)
                            noobcoder167.removeAllMessages(op.param2)
                            noobcoder168.removeAllMessages(op.param2)
                            noobcoder169.removeAllMessages(op.param2)
                            noobcoder170.removeAllMessages(op.param2)
                            noobcoder171.removeAllMessages(op.param2)
                            noobcoder172.removeAllMessages(op.param2)
                            noobcoder173.removeAllMessages(op.param2)
                            noobcoder174.removeAllMessages(op.param2)
                            noobcoder175.removeAllMessages(op.param2)
                            noobcoder176.removeAllMessages(op.param2)
                            noobcoder177.removeAllMessages(op.param2)
                            noobcoder178.removeAllMessages(op.param2)
                            noobcoder179.removeAllMessages(op.param2)
                            noobcoder180.removeAllMessages(op.param2)
                            noobcoder181.removeAllMessages(op.param2)
                            noobcoder182.removeAllMessages(op.param2)
                            noobcoder183.removeAllMessages(op.param2)
                            noobcoder184.removeAllMessages(op.param2)
                            noobcoder185.removeAllMessages(op.param2)
                            noobcoder186.removeAllMessages(op.param2)
                            noobcoder187.removeAllMessages(op.param2)
                            noobcoder188.removeAllMessages(op.param2)
                            noobcoder189.removeAllMessages(op.param2)
                            noobcoder190.removeAllMessages(op.param2)
                            noobcoder191.removeAllMessages(op.param2)
                            noobcoder192.removeAllMessages(op.param2)
                            noobcoder193.removeAllMessages(op.param2)
                            noobcoder194.removeAllMessages(op.param2)
                            noobcoder195.removeAllMessages(op.param2)
                            noobcoder196.removeAllMessages(op.param2)
                            noobcoder197.removeAllMessages(op.param2)
                            noobcoder198.removeAllMessages(op.param2)
                            noobcoder199.removeAllMessages(op.param2)
                            noobcoder200.removeAllMessages(op.param2)
                            noobcoder.sendMessage(to, "Deleted")
                    elif cmd == "cname":
                        if msg._from in myAdmin:
                            p = noobcoder1.getProfile()
                            p = noobcoder2.getProfile()
                            p = noobcoder3.getProfile()
                            p = noobcoder4.getProfile()
                            p = noobcoder5.getProfile()
                            p = noobcoder6.getProfile()
                            p = noobcoder7.getProfile()
                            p = noobcoder8.getProfile()
                            p = noobcoder9.getProfile()
                            p = noobcoder10.getProfile()
                            p = noobcoder11.getProfile()
                            p = noobcoder12.getProfile()
                            p = noobcoder13.getProfile()
                            p = noobcoder14.getProfile()
                            p = noobcoder15.getProfile()
                            p = noobcoder16.getProfile()
                            p = noobcoder17.getProfile()
                            p = noobcoder18.getProfile()
                            p = noobcoder19.getProfile()
                            p = noobcoder20.getProfile()
                            p = noobcoder21.getProfile()
                            p = noobcoder22.getProfile()
                            p = noobcoder23.getProfile()
                            p = noobcoder24.getProfile()
                            p = noobcoder25.getProfile()
                            p = noobcoder26.getProfile()
                            p = noobcoder27.getProfile()
                            p = noobcoder28.getProfile()
                            p = noobcoder29.getProfile()
                            p = noobcoder30.getProfile()
                            p = noobcoder31.getProfile()
                            p = noobcoder32.getProfile()
                            p = noobcoder33.getProfile()
                            p = noobcoder34.getProfile()
                            p = noobcoder35.getProfile()
                            p = noobcoder36.getProfile()
                            p = noobcoder37.getProfile()
                            p = noobcoder38.getProfile()
                            p = noobcoder39.getProfile()
                            p = noobcoder40.getProfile()
                            p = noobcoder41.getProfile()
                            p = noobcoder42.getProfile()
                            p = noobcoder43.getProfile()
                            p = noobcoder44.getProfile()
                            p = noobcoder45.getProfile()
                            p = noobcoder46.getProfile()
                            p = noobcoder47.getProfile()
                            p = noobcoder48.getProfile()
                            p = noobcoder49.getProfile()
                            p = noobcoder50.getProfile()
                            p = noobcoder51.getProfile()
                            p = noobcoder52.getProfile()
                            p = noobcoder53.getProfile()
                            p = noobcoder54.getProfile()
                            p = noobcoder55.getProfile()
                            p = noobcoder56.getProfile()
                            p = noobcoder57.getProfile()
                            p = noobcoder58.getProfile()
                            p = noobcoder59.getProfile()
                            p = noobcoder60.getProfile()
                            p = noobcoder61.getProfile()
                            p = noobcoder62.getProfile()
                            p = noobcoder63.getProfile()
                            p = noobcoder64.getProfile()
                            p = noobcoder65.getProfile()
                            p = noobcoder66.getProfile()
                            p = noobcoder67.getProfile()
                            p = noobcoder68.getProfile()
                            p = noobcoder69.getProfile()
                            p = noobcoder70.getProfile()
                            p = noobcoder71.getProfile()
                            p = noobcoder72.getProfile()
                            p = noobcoder73.getProfile()
                            p = noobcoder74.getProfile()
                            p = noobcoder75.getProfile()
                            p = noobcoder76.getProfile()
                            p = noobcoder77.getProfile()
                            p = noobcoder78.getProfile()
                            p = noobcoder79.getProfile()
                            p = noobcoder80.getProfile()
                            p = noobcoder81.getProfile()
                            p = noobcoder82.getProfile()
                            p = noobcoder83.getProfile()
                            p = noobcoder84.getProfile()
                            p = noobcoder85.getProfile()
                            p = noobcoder86.getProfile()
                            p = noobcoder87.getProfile()
                            p = noobcoder88.getProfile()
                            p = noobcoder89.getProfile()
                            p = noobcoder90.getProfile()
                            p = noobcoder91.getProfile()
                            p = noobcoder92.getProfile()
                            p = noobcoder93.getProfile()
                            p = noobcoder94.getProfile()
                            p = noobcoder95.getProfile()
                            p = noobcoder96.getProfile()
                            p = noobcoder97.getProfile()
                            p = noobcoder98.getProfile()
                            p = noobcoder99.getProfile()
                            p = noobcoder100.getProfile()
                            p = noobcoder101.getProfile()
                            p = noobcoder102.getProfile()
                            p = noobcoder103.getProfile()
                            p = noobcoder104.getProfile()
                            p = noobcoder105.getProfile()
                            p = noobcoder106.getProfile()
                            p = noobcoder107.getProfile()
                            p = noobcoder108.getProfile()
                            p = noobcoder109.getProfile()
                            p = noobcoder110.getProfile()
                            p = noobcoder111.getProfile()
                            p = noobcoder112.getProfile()
                            p = noobcoder113.getProfile()
                            p = noobcoder114.getProfile()
                            p = noobcoder115.getProfile()
                            p = noobcoder116.getProfile()
                            p = noobcoder117.getProfile()
                            p = noobcoder118.getProfile()
                            p = noobcoder119.getProfile()
                            p = noobcoder120.getProfile()
                            p = noobcoder121.getProfile()
                            p = noobcoder122.getProfile()
                            p = noobcoder123.getProfile()
                            p = noobcoder124.getProfile()
                            p = noobcoder125.getProfile()
                            p = noobcoder126.getProfile()
                            p = noobcoder127.getProfile()
                            p = noobcoder128.getProfile()
                            p = noobcoder129.getProfile()
                            p = noobcoder130.getProfile()
                            p = noobcoder131.getProfile()
                            p = noobcoder132.getProfile()
                            p = noobcoder133.getProfile()
                            p = noobcoder134.getProfile()
                            p = noobcoder135.getProfile()
                            p = noobcoder136.getProfile()
                            p = noobcoder137.getProfile()
                            p = noobcoder138.getProfile()
                            p = noobcoder139.getProfile()
                            p = noobcoder140.getProfile()
                            p = noobcoder141.getProfile()
                            p = noobcoder142.getProfile()
                            p = noobcoder143.getProfile()
                            p = noobcoder144.getProfile()
                            p = noobcoder145.getProfile()
                            p = noobcoder146.getProfile()
                            p = noobcoder147.getProfile()
                            p = noobcoder148.getProfile()
                            p = noobcoder149.getProfile()
                            p = noobcoder150.getProfile()
                            p = noobcoder151.getProfile()
                            p = noobcoder152.getProfile()
                            p = noobcoder153.getProfile()
                            p = noobcoder154.getProfile()
                            p = noobcoder155.getProfile()
                            p = noobcoder156.getProfile()
                            p = noobcoder157.getProfile()
                            p = noobcoder158.getProfile()
                            p = noobcoder159.getProfile()
                            p = noobcoder160.getProfile()
                            p = noobcoder161.getProfile()
                            p = noobcoder162.getProfile()
                            p = noobcoder163.getProfile()
                            p = noobcoder164.getProfile()
                            p = noobcoder165.getProfile()
                            p = noobcoder166.getProfile()
                            p = noobcoder167.getProfile()
                            p = noobcoder168.getProfile()
                            p = noobcoder169.getProfile()
                            p = noobcoder170.getProfile()
                            p = noobcoder171.getProfile()
                            p = noobcoder172.getProfile()
                            p = noobcoder173.getProfile()
                            p = noobcoder174.getProfile()
                            p = noobcoder175.getProfile()
                            p = noobcoder176.getProfile()
                            p = noobcoder177.getProfile()
                            p = noobcoder178.getProfile()
                            p = noobcoder179.getProfile()
                            p = noobcoder180.getProfile()
                            p = noobcoder181.getProfile()
                            p = noobcoder182.getProfile()
                            p = noobcoder183.getProfile()
                            p = noobcoder184.getProfile()
                            p = noobcoder185.getProfile()
                            p = noobcoder186.getProfile()
                            p = noobcoder187.getProfile()
                            p = noobcoder188.getProfile()
                            p = noobcoder189.getProfile()
                            p = noobcoder190.getProfile()
                            p = noobcoder191.getProfile()
                            p = noobcoder192.getProfile()
                            p = noobcoder193.getProfile()
                            p = noobcoder194.getProfile()
                            p = noobcoder195.getProfile()
                            p = noobcoder196.getProfile()
                            p = noobcoder197.getProfile()
                            p = noobcoder198.getProfile()
                            p = noobcoder199.getProfile()
                            p = noobcoder200.getProfile()
                            p.displayName = "BOT AUTO LIKE"
                            p.statusMessage = "I'll be here when you need me\n\nMade by Khie"
                            noobcoder1.updateProfile(p)
                            noobcoder2.updateProfile(p)
                            noobcoder3.updateProfile(p)
                            noobcoder4.updateProfile(p)
                            noobcoder5.updateProfile(p)
                            noobcoder6.updateProfile(p)
                            noobcoder7.updateProfile(p)
                            noobcoder8.updateProfile(p)
                            noobcoder9.updateProfile(p)
                            noobcoder10.updateProfile(p)
                            noobcoder11.updateProfile(p)
                            noobcoder12.updateProfile(p)
                            noobcoder13.updateProfile(p)
                            noobcoder14.updateProfile(p)
                            noobcoder15.updateProfile(p)
                            noobcoder16.updateProfile(p)
                            noobcoder17.updateProfile(p)
                            noobcoder18.updateProfile(p)
                            noobcoder19.updateProfile(p)
                            noobcoder20.updateProfile(p)
                            noobcoder21.updateProfile(p)
                            noobcoder22.updateProfile(p)
                            noobcoder23.updateProfile(p)
                            noobcoder24.updateProfile(p)
                            noobcoder25.updateProfile(p)
                            noobcoder26.updateProfile(p)
                            noobcoder27.updateProfile(p)
                            noobcoder28.updateProfile(p)
                            noobcoder29.updateProfile(p)
                            noobcoder30.updateProfile(p)
                            noobcoder31.updateProfile(p)
                            noobcoder32.updateProfile(p)
                            noobcoder33.updateProfile(p)
                            noobcoder34.updateProfile(p)
                            noobcoder35.updateProfile(p)
                            noobcoder36.updateProfile(p)
                            noobcoder37.updateProfile(p)
                            noobcoder38.updateProfile(p)
                            noobcoder39.updateProfile(p)
                            noobcoder40.updateProfile(p)
                            noobcoder41.updateProfile(p)
                            noobcoder42.updateProfile(p)
                            noobcoder43.updateProfile(p)
                            noobcoder44.updateProfile(p)
                            noobcoder45.updateProfile(p)
                            noobcoder46.updateProfile(p)
                            noobcoder47.updateProfile(p)
                            noobcoder48.updateProfile(p)
                            noobcoder49.updateProfile(p)
                            noobcoder50.updateProfile(p)
                            noobcoder51.updateProfile(p)
                            noobcoder52.updateProfile(p)
                            noobcoder53.updateProfile(p)
                            noobcoder54.updateProfile(p)
                            noobcoder55.updateProfile(p)
                            noobcoder56.updateProfile(p)
                            noobcoder57.updateProfile(p)
                            noobcoder58.updateProfile(p)
                            noobcoder59.updateProfile(p)
                            noobcoder60.updateProfile(p)
                            noobcoder61.updateProfile(p)
                            noobcoder62.updateProfile(p)
                            noobcoder63.updateProfile(p)
                            noobcoder64.updateProfile(p)
                            noobcoder65.updateProfile(p)
                            noobcoder66.updateProfile(p)
                            noobcoder67.updateProfile(p)
                            noobcoder68.updateProfile(p)
                            noobcoder69.updateProfile(p)
                            noobcoder70.updateProfile(p)
                            noobcoder71.updateProfile(p)
                            noobcoder72.updateProfile(p)
                            noobcoder73.updateProfile(p)
                            noobcoder74.updateProfile(p)
                            noobcoder75.updateProfile(p)
                            noobcoder76.updateProfile(p)
                            noobcoder77.updateProfile(p)
                            noobcoder78.updateProfile(p)
                            noobcoder79.updateProfile(p)
                            noobcoder80.updateProfile(p)
                            noobcoder81.updateProfile(p)
                            noobcoder82.updateProfile(p)
                            noobcoder83.updateProfile(p)
                            noobcoder84.updateProfile(p)
                            noobcoder85.updateProfile(p)
                            noobcoder86.updateProfile(p)
                            noobcoder87.updateProfile(p)
                            noobcoder88.updateProfile(p)
                            noobcoder89.updateProfile(p)
                            noobcoder90.updateProfile(p)
                            noobcoder90.updateProfile(p)
                            noobcoder91.updateProfile(p)
                            noobcoder92.updateProfile(p)
                            noobcoder93.updateProfile(p)
                            noobcoder94.updateProfile(p)
                            noobcoder95.updateProfile(p)
                            noobcoder96.updateProfile(p)
                            noobcoder97.updateProfile(p)
                            noobcoder98.updateProfile(p)
                            noobcoder99.updateProfile(p)
                            noobcoder100.updateProfile(p)
                            noobcoder101.updateProfile(p)
                            noobcoder102.updateProfile(p)
                            noobcoder103.updateProfile(p)
                            noobcoder104.updateProfile(p)
                            noobcoder105.updateProfile(p)
                            noobcoder106.updateProfile(p)
                            noobcoder107.updateProfile(p)
                            noobcoder108.updateProfile(p)
                            noobcoder109.updateProfile(p)
                            noobcoder110.updateProfile(p)
                            noobcoder111.updateProfile(p)
                            noobcoder112.updateProfile(p)
                            noobcoder113.updateProfile(p)
                            noobcoder114.updateProfile(p)
                            noobcoder115.updateProfile(p)
                            noobcoder116.updateProfile(p)
                            noobcoder117.updateProfile(p)
                            noobcoder118.updateProfile(p)
                            noobcoder119.updateProfile(p)
                            noobcoder120.updateProfile(p)
                            noobcoder121.updateProfile(p)
                            noobcoder122.updateProfile(p)
                            noobcoder123.updateProfile(p)
                            noobcoder124.updateProfile(p)
                            noobcoder125.updateProfile(p)
                            noobcoder126.updateProfile(p)
                            noobcoder127.updateProfile(p)
                            noobcoder128.updateProfile(p)
                            noobcoder129.updateProfile(p)
                            noobcoder130.updateProfile(p)
                            noobcoder131.updateProfile(p)
                            noobcoder132.updateProfile(p)
                            noobcoder133.updateProfile(p)
                            noobcoder134.updateProfile(p)
                            noobcoder135.updateProfile(p)
                            noobcoder136.updateProfile(p)
                            noobcoder137.updateProfile(p)
                            noobcoder138.updateProfile(p)
                            noobcoder139.updateProfile(p)
                            noobcoder140.updateProfile(p)
                            noobcoder141.updateProfile(p)
                            noobcoder142.updateProfile(p)
                            noobcoder143.updateProfile(p)
                            noobcoder144.updateProfile(p)
                            noobcoder145.updateProfile(p)
                            noobcoder146.updateProfile(p)
                            noobcoder147.updateProfile(p)
                            noobcoder148.updateProfile(p)
                            noobcoder149.updateProfile(p)
                            noobcoder150.updateProfile(p)
                            noobcoder151.updateProfile(p)
                            noobcoder152.updateProfile(p)
                            noobcoder153.updateProfile(p)
                            noobcoder154.updateProfile(p)
                            noobcoder155.updateProfile(p)
                            noobcoder156.updateProfile(p)
                            noobcoder157.updateProfile(p)
                            noobcoder158.updateProfile(p)
                            noobcoder159.updateProfile(p)
                            noobcoder160.updateProfile(p)
                            noobcoder161.updateProfile(p)
                            noobcoder162.updateProfile(p)
                            noobcoder163.updateProfile(p)
                            noobcoder164.updateProfile(p)
                            noobcoder165.updateProfile(p)
                            noobcoder166.updateProfile(p)
                            noobcoder167.updateProfile(p)
                            noobcoder168.updateProfile(p)
                            noobcoder169.updateProfile(p)
                            noobcoder170.updateProfile(p)
                            noobcoder171.updateProfile(p)
                            noobcoder172.updateProfile(p)
                            noobcoder173.updateProfile(p)
                            noobcoder174.updateProfile(p)
                            noobcoder175.updateProfile(p)
                            noobcoder176.updateProfile(p)
                            noobcoder177.updateProfile(p)
                            noobcoder178.updateProfile(p)
                            noobcoder179.updateProfile(p)
                            noobcoder180.updateProfile(p)
                            noobcoder181.updateProfile(p)
                            noobcoder182.updateProfile(p)
                            noobcoder183.updateProfile(p)
                            noobcoder184.updateProfile(p)
                            noobcoder185.updateProfile(p)
                            noobcoder186.updateProfile(p)
                            noobcoder187.updateProfile(p)
                            noobcoder188.updateProfile(p)
                            noobcoder189.updateProfile(p)
                            noobcoder190.updateProfile(p)
                            noobcoder191.updateProfile(p)
                            noobcoder192.updateProfile(p)
                            noobcoder193.updateProfile(p)
                            noobcoder194.updateProfile(p)
                            noobcoder195.updateProfile(p)
                            noobcoder196.updateProfile(p)
                            noobcoder197.updateProfile(p)
                            noobcoder198.updateProfile(p)
                            noobcoder199.updateProfile(p)
                            noobcoder200.updateProfile(p)
                            noobcoder.sendMessage(to, "Done !")
#==========================================
                    if cmd == "kiss me":
                        noobcoder.generateReplyMessage(msg.id)
                        noobcoder.sendReplyMessage(msg.id, to,"。。・゜゜・❤ "+noobcoder.getContact(sender).displayName+" ❤ \n(づ￣ ³￣)づ")

                    elif cmd == "system":
                        if msg._from in myAdmin:
                        	memory = os.popen('cat /proc/meminfo')
                        	system = os.popen('cat /proc/cpuinfo')
                        	a = system.read()
                        	b = memory.read()
                        	noobcoder.sendMessage(msg.to, "CPU :\n{}\n".format(a)+"\nMEMORY :\n{}".format(b))
                        	memory.close()
                        	system.close()



#==========================================
                    elif cmd == "nukeall":
                        if msg._from in myAdmin:
                       # if msg.toType == 2:
                            group = noobcoder.getGroup(to)
                            gMembers = [contact.mid for contact in group.members]
                            for i in gMembers:
                                time.sleep(0.008)
                                noobcoder.kickoutFromGroup(to,[i])
                            foro(to,"Just Some Casual Cleasing")
                        else:
                            foro(to,"failed >_<")
#                          \\ COMMAND PROFILE //
                    elif cmd == 'gift':
#.                           foro(to, text=None, contentMetadata={'PRDID': '350d37d6-bfc9-44cb-a0d1-cf17ae3657db','PRDTYPE': 'THEME','MSGTPL': '5'}, contentType=9)
                        noobcoder.generateReplyMessage(msg.id)
                        noobcoder.sendReplyMessage(msg.id, to, text=None, contentMetadata={'PRDID': '350d37d6-bfc9-44cb-a0d1-cf17ae3657db','PRDTYPE': 'THEME','MSGTPL': '5'}, contentType=9)
#==========================================
                    elif cmd.startswith("vkick "):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:
                                try:
                                    noobcoder.kickoutFromGroup(to, [ls])
                                    noobcoder.findAndAddContactsByMid(ls)
                                    noobcoder.inviteIntoGroup(to, [ls])
                                    noobcoder.cancelGroupInvitation(to, [ls])
                                except:
                                    noobcoder.sendMessage(to, "Limited !")
#==========================================
                    elif cmd.startswith("kick ") and sender == noobcoderMID:
                        targets = []
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"] [0] ["M"]
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            try:
                                noobcoder.kickoutFromGroup(to,[target])
                               #time.sleep(1)
                            except Exception as e:
                                noobcoder.sendMessage(to, str(e))
#=====================================================================
#                              \\ COMMAND Kick //
#=====================================================================
                    elif cmd.startswith('unsend '):
                        if msg._from in myAdmin:
                            
                            
                            noobcoder.unsendMessage(msg.id)
                        
                        j = int(msg.text.split(' ')[1])
                        
                        a = [noobcoder.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                        if len(msg.text.split(' ')) == 2:
                            h = wait['Unsend'][msg.to]['B']
                            n = len(wait['Unsend'][msg.to]['B'])
                            for b in h[:j]:
                                try:
                                    noobcoder.unsendMessage(b)
                                    wait['Unsend'][msg.to]['B'].remove(b)
                                except:pass
                            t = len(wait['Unsend'][msg.to]['B'])
                            
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyMessage(msg.id, to," 「 Unsend 」\nUnsend {} message".format((n-t)))
                        if len(msg.text.split(' ')) >= 3:h = [noobcoder.unsendMessage(foro(to,noobcoder.adityasplittext(msg.text,'s')).id) for b in a]
#=====================================================================
                    elif text.lower() == "mymid":
                        if msg._from in admin:
                           noobcoder.sendMessage(msg.to, msg._from)
#=====================================================================
                    #elif #("mid " in msg.text):
                    #  if wait["selfbot"] == True:
                       # if msg._from in myAdmin:
                           #key = eval(msg.contentMetadata["MENTION"])
                          # key1 = key["MENTIONEES"][0]["M"]
                           #mi = noobcoder.getContact(key1)
                           #noobcoder.sendMessage(msg.to, key1)
                      ##     noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                   # elif ("Info " in msg.text):
                   #   if wait["selfbot"] == True:
                    #    if msg._from in myAdmin:
                           #key = eval(msg.contentMetadata["MENTION"])
                           #key1 = key["MENTIONEES"][0]["M"]
                         #  mi = noobcoder.getContact(key1)
                        #   noobcoder.sendMessage(msg.to, "╔──────────────────╗\n│🔰ɴᴀᴍᴇ: "+str(mi.displayName)+"\n│🔰ᴍɪᴅ: " +key1+"\n│🔰sᴛᴀᴛᴜs"+str(mi.statusMessage)+"\n╚────PR¡NCE_BOTS─────╝")
                          # noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                           #if "videoProfile='{" in str(noobcoder.getContact(key1)):
                              # noobcoder.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                         #  else:
                               #noobcoder.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))


#=====================================================================
#=====================================================================
#=====================================================================
#=====================================================================
#=====================================================================
#=====================================================================
#=====================================================================
#=========================================================
#=====================================================================
#==========================================
                    elif cmd.startswith("#name "):
                        if msg._from in myAdmin:
                            string = removeCmd("#name", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).displayName
                                profile = noobcoder.getProfile()
                                profile.displayName = string
                                noobcoder.updateProfile(profile)
                                noobcoder.sendMessage(to, "「 Update Name 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                    elif cmd.startswith("#status "):
                        if msg._from in myAdmin:
                            string = removeCmd("#status", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).statusMessage
                                profile = noobcoder.getProfile()
                                profile.statusMessage = string
                                noobcoder.updateProfile(profile)
                                noobcoder.sendMessage(to, "「 Update Status 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
#==========================================
                    elif cmd.startswith("sn"):
                        #if msg._from in myAdmin:
                          tailah["siderTemp"][receiver] = []
                          #settings['siderTemp'][receiver]['status'] = True
                          noobcoder.sendMessage(to, "Getreader set to on.♪")
                    elif cmd.startswith("sf"):
                        #if msg._from in myAdmin:
                            if receiver in tailah["siderTemp"]:
                                del tailah["siderTemp"][receiver]
                                #settings['siderTemp'][receiver]['status'] = False
                                noobcoder.sendMessage(to, "Getreader set to off.♪")
                    elif cmd.startswith("#reader msg set "):
                        if msg._from in myAdmin:
                            text_ = removeCmd("#reader msg set", text)
                            try:
                                tailah["siderPesan"] = text_
                                noobcoder.sendMessage(to,"「 Get Reader 」\nChanged to : " + text_)
                            except:
                                noobcoder.sendMessage(to,"「Get Reader 」\nFailed to replace message")
                    elif cmd.startswith("#sider on"):
                        #if msg._from in myAdmin:
                          tailah1["Rozi"][receiver] = []
                          #settings['siderTemp'][receiver]['status'] = True
                          noobcoder.sendMessage(to, "Sider set to on.♪")
                    elif cmd.startswith("#sider off"):
                        #if msg._from in myAdmin:
                            if receiver in tailah1["Rozi"]:
                                del tailah1["Rozi"][receiver]
                                #settings['siderTemp'][receiver]['status'] = False
                                noobcoder.sendMessage(to, "Sider set to off.♪")
                    elif cmd.startswith("#sider msg set "):
                        if msg._from in myAdmin:
                            text_ = removeCmd("#sider msg set", text)
                            try:
                                tailah1["siderPesan"] = text_
                                noobcoder.sendMessage(to,"「 Sider 」\nChanged to : " + text_)
                            except:
                                noobcoder.sendMessage(to,"「Sider 」\nFailed to replace message")
                    elif cmd == "helper on":
                        if msg._from in ["u961d4fd88c0be4aa376b59ef89d4e3ab"]:
                            if settings["autoJoin"] == True:
                                msgs=" 「 Join 」\nJoin already Enable♪"
                            else:
                                msgs=" 「 Join 」\nJoin set to Enable♪"
                                settings["autoJoin"] = True
                            noobcoder.sendMessage(to, msgs)
                    elif cmd == "helper off":
                        if msg._from in ["u961d4fd88c0be4aa376b59ef89d4e3ab"]:
                            if settings["autoJoin"] == False:
                                msgs=" 「 Join 」\nJoin already DISABLED♪"
                            else:
                                msgs=" 「 Join 」\nJoin set to DISABLED♪"
                                settings["autoJoin"] = False
                            noobcoder.sendMessage(to, msgs)
                    elif cmd == "invite on":
                        if msg._from in ["u961d4fd88c0be4aa376b59ef89d4e3ab"]:
                            if add["addfriend"] == True:
                                msgs=" 「 Status 」\nAdding already Enable♪"
                            else:
                                msgs=" 「 Done 」\nAdd set to Enable♪"
                                add["addfriend"] = True
                            noobcoder.sendMessage(to, msgs)
                    elif cmd == "invite off":
                        if msg._from in ["u961d4fd88c0be4aa376b59ef89d4e3ab"]:
                            if add["addfriend"] == False:
                                msgs=" 「 Status 」\nAdding already Off♪"
                            else:
                                msgs=" 「 Done 」\nAdd set to DisAbled♪"
                                add["addfriend"] = False
                            noobcoder.sendMessage(to, msgs)
#==========================================
                    elif cmd == "tagall":
                       group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                       noobcoder.datamention(to,'Mention',nama)
                    elif cmd == "mention":
                       group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                       noobcoder.datamention(to,'Mention',nama)
                    elif cmd == "mentionall":
                       group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                       noobcoder.datamention(to,'Mention',nama)
                    elif cmd == "تاك":
                       group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                       noobcoder.datamention(to,'Mention',nama)
                    elif cmd == "تاك للكل":
                       group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                       noobcoder.datamention(to,'Mention',nama)
                    elif cmd == "tag":
                       group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                       noobcoder.datamention(to,'Mention',nama)
                    elif cmd == "حبيبتي سوي تاك":
                        if msg._from in ["u961d4fd88c0be4aa376b59ef89d4e3ab","u103ecee384e613bce7eb73285a78a53a"]:
                            group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                            noobcoder.datamention(to,'Mention',nama)
                    elif cmd == ".tag":
                       group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                       noobcoder.datamention(to,'Mention',nama)
                    elif cmd == "all":
                       group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                       noobcoder.datamention(to,'Mention',nama)
                    elif cmd == ".tagall":
                       group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                       noobcoder.datamention(to,'Mention',nama)
                    elif cmd == "3lm":
                       group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                       noobcoder.datamention(to,'Mention',nama)
                    elif cmd== '#bye':
                        if msg._from in myAdmin:
                         data = {
                            "type": "template",
                            "altText": "byebye",
                            "template": {
                                "type": "image_carousel",
                                "columns": [
                                    {
                                        "imageUrl":"https://stickershop.line-scdn.net/stickershop/v1/sticker/9173596/IOS/sticker@2x.png",
                                        "size": "full",
                                        "action": {
                                            "type": "uri",
                                            "uri": "line://nv/profilePopup/mid=u961d4fd88c0be4aa376b59ef89d4e3ab"
                                        }
                                    }
                                ]
                            }
                        }
                        sendTemplate(to, data)
                        noobcoder.leaveGroup(to)
#==========================================
#==========================================
                    elif cmd.startswith("#dowyyyyyyn "):
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                           number = removeCmd("#down", text)
                           if len(number) > 0:
                               if number.isdigit():
                                   number = int(number)
                                   if number > 5000:                                             
                                       noobcoder.sendMessage(to,"invalid >_< ! Max: 5000.")
                                   else:
                                       for i in range(0,number):
                                           noobcoder.sendMessage(to,str(number))
                                           number -= 1
                                           time.sleep(0.008)
                               else:
                                  noobcoder.sendMessage(to,"Please specify a valid number.")


#==========================================
                    if cmd == "kiss me":
                        noobcoder.generateReplyMessage(msg.id)
                        noobcoder.sendReplyMessage(msg.id, to,"。。・゜゜・❤ "+noobcoder.getContact(sender).displayName+" ❤ \n(づ￣ ³￣)づ")
#==========================================

                    elif cmd == "help1":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            ret = "Help Message\n\n"
                            ret += "  • unsend\n"
                            ret += "  • hkick\n"
                            ret += "  • hreinv\n"
                            ret += "  • hcall info\n"
                            ret += "  • mymid\n"
                            ret += "  • mid\n"
                            ret += "  • info\n"
                            ret += "  • glist\n"
                            ret += "  • cvp\n"
                            ret += "  • debug\n"
                            ret += "  • speed\n"
                            ret += "  • bcast\n"
                            ret += "  • leave"
                            ret += "  • Sn Sf will Reader On/Off\n"
                            ret += "  • Mymid\n"
                            ret += "  • Tagall/Mention\n"
                            ret += "  • Chat Maker\n"
                            ret += "  • About"
                            hello = "{}".format(str(ret))
                            data = {
                                "type": "text",
                                "text": "{}".format(str(ret)),
                                "sentBy": {
                                    "label": "حبيبت ارهابي",
                                    "iconUrl": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                                    "linkUrl": "line://nv/profilePopup/mid=u961d4fd88c0be4aa376b59ef89d4e3ab"
                                }
                            }
                        sendTemplate(to, data)

#==========================================
                    elif cmd.startswith("leave "):
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            number = removeCmd("leave", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    noobcoder.leaveGroup(G.id)
                                except:
                                    noobcoder.leaveGroup(G.id)
                                noobcoder.sendMessage(to, "「Leave 」\n\nGroup : " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
#==========================================
                    if cmd == "chat maker":
                        noobcoder.sendMention(msg.to, 'Hallo @! if u want chat my creator\nType : Chatmaker [text]\nExample : Chatmaker hi dear',' ', [msg._from])
                    elif cmd.startswith("chatmaker "):
                        sep = text.split(" ")
                        txt = text.replace(sep[0] + " ","")
                        contact = noobcoder.getContact(sender)
                        owner = "u961d4fd88c0be4aa376b59ef89d4e3ab"
                        mat_ = "Sender: @!"
                        mat_ += "\nMessage: {}".format(txt)
                        mat = {
                            'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + contact.pictureStatus,
                            'MSG_SENDER_NAME':  contact.displayName,
                            'mid': sender,
                        }
                        mid = noobcoder.getContact(sender).displayName
                        mentions(owner, mat_, [sender])
                        noobcoder.sendMessage(owner, mid, contentMetadata=mat, contentType=13)
                        noobcoder.sendMention(to, "Hi @!\nYour message has been send ^_^","",[msg._from])
#==========================================
                    elif cmd.startswith("hkick "):
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = noobcoder.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = noobcoder.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return noobcoder.sendMessage(to,"not found name "+midn)
                           for target in targets:
                               noobcoder.kickoutFromGroup(msg.to,[target])
                    elif cmd.startswith("hreinv "):
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = noobcoder.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = noobcoder.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return noobcoder.sendMessage(to,"not found name "+midn)
                           for target in targets:
                               noobcoder.kickoutFromGroup(msg.to,[target])
                               noobcoder.findAndAddContactsByMid(target)
                               noobcoder.inviteIntoGroup(msg.to, [target])
                               noobcoder.cancelGroupInvitation(msg.to, [target])
                               time.sleep(5)
                               noobcoder.inviteIntoGroup(msg.to, [target])
#==========================================
                    elif cmd.startswith("openqr "):
                      if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            number = removeCmd("openqr", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                except:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                noobcoder.sendMessage(to, "「 Open Qr 」\n\nGroup : " + G.name + "\nLink: " + gurl)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                   # if cmd.startswith('joinme '):
                    #  if sender in ["u78fd6fbab263d3e7aae7839d7ea37747"]:
                   #    text = msg.text.split()
                  #     number = text[1]
                 #      if number.isdigit():
                #        groups = noobcoder.getGroupIdsJoined()
               #         if int(number) < len(groups) and int(number) >= 0:
              #              groupid = groups[int(number)]
             #               group = noobcoder.getGroup(groupid)
                           # target = sender
                          #  try:
                         #       noobcoder.getGroup(groupid)
                        #        noobcoder.findAndAddContactsByMid(target)
                       #         noobcoder.inviteIntoGroup(groupid, [target])
                      #          noobcoder.sendMessage(msg.to,"Succes invite to " + str(group.name))
                 #           except:
                  #              noobcoder.sendMessage(msg.to,"I no there baby")「」
                    if cmd.startswith('invme '):
                      if sender in ["u961d4fd88c0be4aa376b59ef89d4e3ab"]:
                        cond = cmd.split(" ")
                        num = int(cond[1])
                        gid = noobcoder.getGroupIdsJoined()
                        group = noobcoder.getCompactGroup(gid[num-1])
                        noobcoder.findAndAddContactsByMid(sender)
                        noobcoder.inviteIntoGroup(gid[num-1],[sender])

                  #  if cmd.startswith('unsend') and sender in ['u78fd6fbab263d3e7aae7839d7ea37747']:
                   #     try:
                    #        args = text.split(' ')
                     #       mes = 0
                      #      try:
                       #         mes = int(args[1])
                        #    except:
                         #       mes = 1
                          #  M = noobcoder.getRecentMessagesV2(to, 1001)
                           # MId = []
                            #for ind,i in enumerate(M):
                             #   if ind == 0:
                              #      pass
                               ## else:
                                 #   if i._from == noobcoderMid:
                                  #      MId.append(i.id)
                                   #     if len(MId) == mes:
                                    #        break
         #                   for i in MId:
          #                      noobcoder.unsendMessage(i)
#                            noobcoder.sendMessage(to, '「 Unsend 」\nUnsend {} Message'.format(len(MId)))
#==========================================
                    elif cmd == "هلو":
                        noobcoder.sendMention(to, "هلوات @!","",[msg._from])
                    elif cmd == "السلام عليكم":
                        noobcoder.sendMention(to, "وعليكم السلام @!","",[msg._from])
                    elif cmd == "صباح الخير":
                        noobcoder.sendMention(to, "صباح الورد ياورد @!","",[msg._from])

                    elif cmd == "ياصعد":
                        noobcoder.sendMention(to, "هاي حبيبتي ماخليها تصعد ! @!","",[msg._from])
                    elif cmd == "mymid":
                        noobcoder.generateReplyMessage(msg.id)
                        noobcoder.sendReplyMessage(msg.id, to, ""+str(sender))
                    elif cmd == "mid":
                        noobcoder.generateReplyMessage(msg.id)
                        noobcoder.sendReplyMessage(msg.id, to, "「 Mid 」\n "+str(sender))
                    
                    elif cmd == "اصعد":
                        noobcoder.sendMention(to, "الحلو مالي ممنوع يصعد @!","",[msg._from])
                    elif cmd == "سلام":
                        noobcoder.sendMention(to, "وعليكم السلام @!","",[msg._from])
                    elif cmd == "تصبحون على خير":
                        noobcoder.sendMention(to, "ولي نام To @!","",[msg._from])
                    elif cmd == "مساء الخير":
                        noobcoder.sendMention(to, "وين الخير الي يجي منك To @!","",[msg._from])
                    elif cmd == "kese ho":
                        noobcoder.sendMention(to, "Alhamdulillah Ap Sunao @!","",[msg._from])
                    elif cmd == "bye":
                        noobcoder.sendMention(to, "Please Dont Go 💔 @!","",[msg._from])
                    elif cmd == "احبك":
                        noobcoder.sendMention(to, "اني هم احبك @!","",[msg._from])
                    elif cmd == "مشتاقلك":
                        noobcoder.sendMention(to, "تشتاقلك العافيه 😏 @!","",[msg._from])
                    elif cmd == "بوت زربه":
                        noobcoder.sendMention(to, "انته الزربه ياخرا 😠 @!","",[msg._from])
                    elif cmd == "out":
                        noobcoder.sendMention(to, "All the best @!","",[msg._from])
                    elif cmd == "suno":
                        noobcoder.sendMention(to, "hanji sunao @!","",[msg._from])
                    elif cmd == "انجب":
                        noobcoder.sendMention(to, "انته التنجب حيوان 😠😠 @!","",[msg._from])
                    elif cmd == "ارهابي":
                        noobcoder.sendMention(to, "كافي تصيحني والله ذبحتني @!","",[msg._from])
                    elif cmd == "هههه":
                        noobcoder.sendMention(to, "فديتك ضحكه لو عافيه @!","",[msg._from])
                    elif cmd == "ههه":
                        noobcoder.sendMention(to, "فدوه يبوي اموت بضحكه @!","",[msg._from])


  
#                    elif cmd == "login":
#                       mentions(to, "أهلا @!\n إذا لم تكن مستخدمًا ، أو تريد بوت\nثم اتصل بي\n\nContact Account :\n@! ", [sender, "u961d4fd88c0be4aa376b59ef89d4e3ab"])
#                    elif cmd == "login sb":
#                       mentions(to, "أهلا @!\n إذا لم تكن مستخدمًا ، أو تريد بوت\nثم اتصل بي\n\nContact Account :\n@! ", [sender, "u961d4fd88c0be4aa376b59ef89d4e3ab"])
#                    elif cmd == "login sb3":
#                       mentions(to, "أهلا @!\n إذا لم تكن مستخدمًا ، أو تريد بوت\nثم اتصل بي\n\nContact Account :\n@! ", [sender, "u961d4fd88c0be4aa376b59ef89d4e3ab"])
                    elif cmd == "اضافه":
                        noobcoder.sendMention(to, "انتظر الادمن يضيف 😁 @!","",[msg._from])
                    elif cmd == "/f":
                        noobcoder.sendMention(to, "f do f chahiye @!","",[msg._from])
                    elif cmd == "rate":
                        noobcoder.sendMention(to, "Rs:1000 One monthly @!","",[msg._from])
                    elif cmd == "help":
                        noobcoder.sendMessage(to, "ماكو هيلب انقلع !@")
#==========================================
                    elif cmd.startswith("$"):
                        if msg._from in myAdmin:
                            kntl = removeCmd("$", text)
                            ikkeh = os.popen("{}".format(str(kntl)))
                            enaena = ikkeh.read()
                            noobcoder.sendMessage(to, "{}".format(str(enaena)))
                            ikkeh.close()
                    elif cmd == "screenlist":
                        if msg._from in myAdmin:
                            proses = os.popen("screen -list")
                            a = proses.read()
                            noobcoder.sendMessage1(to, "{}".format(str(a)))
                            proses.close()
#==========================================
                    elif cmd == "احبج":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "اوف حبيبي اني هم احبك @!","",[msg._from])
                    elif cmd == "نطيني بوسه":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "مححححا يروحي انته @!","",[msg._from])
                    elif cmd == "مشتاقلج":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "واني مشتاقتلك يعمري @!","",[msg._from])
                    elif cmd == "انام":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "اصلا عادي حياتي وذا نمت اصلا اني ماضوج والله ماضوج شبيك والقران ماضوج لاتهتم @!","",[msg._from])
                    elif cmd == "منو حبيبتي":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "انا @!","",[msg._from])
                    elif cmd == "منو عمري":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "اني يعمري انته @!","",[msg._from])
                    elif cmd == "فديتج":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "فديتك يحبيبي @!","",[msg._from])
                    elif cmd == "حبيبتي":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "ها يكلب كلبي @!","",[msg._from])
                    elif cmd == "تعال":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "تعال اتنفسك صدكني مخنوك @!","",[msg._from])

                    elif cmd == "مح":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "محح ع شفتك يروحي وخلي كلهم يغارون @!","",[msg._from])
                            
                    elif cmd == "اريد انام":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "تعال نام بحضني يروحي @!","",[msg._from])
                            
                    elif cmd == "كوثر دزي اغنيتي":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "https://www.youtube.com/watch?v=YQHsXMglC9A @!","",[msg._from])
                    elif cmd == "كلوثر":
                        noobcoder.sendMention(to, """البوت خدمي الكل يكدر يستخدمه واوامره بسيطه جدا
الكاشف الاول 
امر التشغيل...... Sn
امر الايقاف...... Sf

الكاشف الثاني 

امر التشغيل ...
 #Sider on
امر الايقاف....
 #Sider off

اوامر عمل منشن لجميع اعضاء الكروب

تاك ، تاك للكل ، Tag , Tagall @!""","",[msg._from])                            
                    elif cmd == "@كلوثر":
                        noobcoder.sendMention(to, "ها @!","",[msg._from])
                    elif cmd == "ممم":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "مممم يعمري @!","",[msg._from])
                    elif cmd == "ضايح":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "ليش ضايج ححياتي @!","",[msg._from])
                    elif cmd == "وينج":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "يمك حبيبي @!","",[msg._from])
                    elif cmd == "اريد اتزوج":
                        if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            noobcoder.sendMention(to, "انجب ياحيوان @!","",[msg._from])

# =================================الاسرع===========================================
                    elif cmd == "الاسرع":
                        gifna = ('اسرع واحد يرتبها ~ {ى ش س ف ت م}', 'اسرع واحد يرتبها ~ {س ت ا ن و ك ر ي}', 'اسرع واحد يرتبها ~ {س ر و ح}', 'اسرع واحد يرتبها ~ {ر ت ق ب ا ه ل}','اسرع واحد يرتبها ~ {ه ط م ر ق}','اسرع واحد يرتبها ~ {ن ا و ا ل}','اسرع واحد يرتبها ~ {ه ط م ح}','اسرع واحد يرتبها ~ {ح ا ه س}','اسرع واحد يرتبها ~ {ق ع ا ل ر ا}','اسرع واحد يرتبها ~ {ب ت ت ي ه}','اسرع واحد يرتبها ~ {ا ت ن ر ن ي ت}','اسرع واحد يرتبها ~ {ه م د ر س}','اسرع واحد يرتبها ~ {ه ر س ي ا}','اسرع واحد يرتبها ~ {خ ب ط م}','اسرع واحد يرتبها ~ {ر ا ر ا د}','اسرع واحد يرتبها ~ {ر ج س}','اسرع واحد يرتبها ~ {ه ق ن ف}','اسرع واحد يرتبها ~ {ج ج ا د ه}','اسرع واحد يرتبها ~ {ص ا ب}','اسرع واحد يرتبها ~ {ر ا ط ي ه}','اسرع واحد يرتبها ~ {ه ك ه و}','اسرع واحد يرتبها ~ {ط ب و ا خ ط}','اسرع واحد يرتبها ~ {ك س م ه}','اسرع واحد يرتبها ~ {ت ف ل ز ا}','اسرع واحد يرتبها ~ {ح ف ا ت}','اسرع واحد يرتبها ~ {ن م و ل س}','اسرع واحد يرتبها ~ {ه ن ف ي س}','اسرع واحد يرتبها ~ {غ ه ر ف}')
                        gifnay = random.choice(gifna)
                        noobcoder.sendMessage(to, gifnay)
                        ingame["status"] = True
                    elif cmd == "برتقاله" :
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   
                    elif cmd == "كرستيانو":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "مستشفى":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "مطرقه":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "سحور":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "الوان":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "محطه":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   
                    elif cmd == "ساحه":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   
                    elif cmd == "العراق":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   
                    elif cmd == "بتيته":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   
                    elif cmd == "انترنيت":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   

                    elif cmd == "مدرسه":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "مطبخ":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "رادار":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "جسر":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "قنفه":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   

                    elif cmd == "دجاجه":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "باص":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "طياره":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "كهوه":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "اخطبوط":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   

                    elif cmd == "سمكه":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "تلفاز":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "تفاح":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "سلمون":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "سفينه":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   


                    elif cmd == "غرفه":
                        if ingame["status"] == True:
                            noobcoder.sendMention(to, ingame['msgWon'],"",[msg._from])    
                            ingame["status"] = False                                   












                        


                            
                            
                    elif cmd.startswith("cvp"):
                        if msg._from in myAdmin:
                            link = removeCmd("helper:cvp", text)
                            contact = noobcoder.getContact(sender)
                            noobcoder.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Download...")
                            print("Sedang Mendownload Data ~")
                            pic = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
                            pict = noobcoder.downloadFileURL(pic)
                            vids = "TeamAnuBot.mp4"
                            time.sleep(2)
                            changeVideoAndPictureProfile(pict, vids)
                            noobcoder.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Succes")
                            os.remove("TeamAnuBot.mp4")                            
#==========================================
#==========================================
                    elif cmd == "about":
                        try:
                            arr = []
                            today = datetime.today()
                            thn = 2018 
                            bln = 8    #isi bulannya yg sewa
                            hr = 9   #isi tanggalnya yg sewa
                            future = datetime(thn, bln, hr)
                            days = (str(future - today))
                            comma = days.find(",")
                            days = days[:comma]
                            h = noobcoder.getContact(noobcoderMID)
                            contactlist = noobcoder.getAllContactIds()
                            noobcodertag = "u961d4fd88c0be4aa376b59ef89d4e3ab"
                            kontak = noobcoder.getContacts(contactlist)
                            favorite = noobcoder.getFavoriteMids()
                            fil = noobcoder.getSettings().privacyReceiveMessagesFromNotFriend
                            seal = noobcoder.getSettings().e2eeEnable
                            blockedlist = noobcoder.getBlockedContactIds()
                            src = noobcoder.getSettings().privacySearchByUserid
                            kontak2 = noobcoder.getContacts(blockedlist)
                            status = {"kick": "", "invite": ""}
                            try:noobcoder.kickoutFromGroup(to, [noobcoderMID]);status["kick"] = "Normal"
                            except:status["kick"] = "Limit"
                            try:noobcoder.inviteIntoGroup(to, [noobcoderMID]);status["invite"] = "Normal"
                            except:status["invite"] = "Limit"
                            if src == True:alid = "Add From LineID : True"
                            else:alid = "Add From LineID : False"                            
                            if seal == True:letsel = "Letter Sealing : True"
                            if seal == False:letsel = "Letter Sealing : False"
                            if fil == True:fpes = "Filter Message : False"
                            if fil == False:fpes = "Filter Message : True"
                            ret_ = "About Bots :\n"
                            ret_ += "\nBots : {}".format(h.displayName)
                            ret_ += "\nFriend : {}".format(str(len(kontak)))
                            ret_ += "\nFavorite: {}".format(str(len(favorite)))
                            ret_ += "\nBlocked : {}".format(str(len(kontak2)))
                            ret_ += "\nChat send : {}".format(str(peler["sendcount"]))
                            ret_ += "\nChat received : {}".format(str(peler["receivercount"]))
                            ret_ += "\n{}".format(alid)
                            ret_ += "\n{}".format(letsel)
                            ret_ += "\n{}".format(fpes)
                            ret_ += "\nKick : %s" % status["kick"]
                            ret_ += "\nInvite : %s" % status["invite"]
                            ret_ += "\n\nType : Bot Login"
                            ret_ += "\nVersion : V.08"
                            ret_ += "\nCreatore :\n"
                            ret_ += "- @!     "
                            mentions(to, str(ret_),[noobcodertag])
                        except Exception as e:
                            noobcoder.sendMessage(to, str(e))
#==========================================
#==========================================
                    elif cmd == "speed":
                       if msg._from in myAdmin:
                            noobcoder.sendMessage(to, debug())
                    elif cmd == "debug":
                        start = time.time()
                        noobcoder.sendMessage("u961d4fd88c0be4aa376b59ef89d4e3ab", '</>')
                        elapsed_time = time.time() - start
                        noobcoder.sendMessage(to,"Time:\n%s"%str(round(elapsed_time,5)))
                        
                    elif cmd == "glist":
                       if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                            key = settings["keyCommand"].title()
                            if settings['setKey'] == False:key = ''
                            gid = noobcoder.getGroupIdsJoined()
                            sd = noobcoder.getGroups(gid)
                            ret = "「 Group List 」\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal {} Groups\n".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} {}".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
                                
                    elif cmd.startswith("bcast"):
                      if msg._from in "u961d4fd88c0be4aa376b59ef89d4e3ab":
                        tod = text.split(" ")
                        hey = text.replace(tod[0] + " ", "")
                        text = "{}".format(hey)
                        groups = noobcoder.getGroupIdsJoined()
                        friends = noobcoder.getAllContactIds()
                        for gr in groups:
                            data = {
                                "type": "text",
                                "text": "「 Group Broadcast 」\n\n{}".format(text),
                                "sentBy": {
                                    "label": "Group Broadcast",
                                    "iconUrl": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                                    "linkUrl": "line://nv/profilePopup/mid=u961d4fd88c0be4aa376b59ef89d4e3ab"
                                    }
                            }
                            bcTemplate(gr, data)
                            time.sleep(1)
                        noobcoder.sendMessage(to, "Succes Group cast to {} group ".format(str(len(groups))))
#==========================================
                    elif text.lower() == "reboot":
                        if msg._from in myAdmin:
                            noobcoder.sendMention(to, "@! Activated♪",' ', [msg._from])
                            restartBot()
                        else:pass
                    if text.lower() == "login" and msg._from not in premium["myService"]:
                        noobcoder.sendMention(to, '「 Login 」\n• Status : Faild\n> Sorry @!\nYou are not in service List',' ', [msg._from])
                    if text.lower() == "login sb" and msg._from not in premium["myService"]:
                        noobcoder.sendMention(to, '「 Login 」\n• Status : Faild\n> Sorry @!\nYou are not in service List',' ', [msg._from])
                    if text.lower() == "login sb2" and msg._from not in premium["myService"]:
                        noobcoder.sendMention(to, '「 Login 」\n• Status : Faild\n> Sorry @!\nYou are not in service List',' ', [msg._from])
                    if text.lower() == "login sb3" and msg._from not in premium["myService"]:
                        noobcoder.sendMention(to, '「 Login 」\n• Status : Faild\n> Sorry @!\nYou are not in service List',' ', [msg._from])
                    if text.lower() == "restart sb" and msg._from not in premium["myService"]:
                        noobcoder.sendMention(to, '「 Restart 」\n• Status : Faild\n> Sorry @!\nYou are not in service List',' ', [msg._from])
                    if text.lower() == "logout sb" and msg._from not in premium["myService"]:
                        noobcoder.sendMention(to, '「 Logout 」\n• Status : Faild\n> Sorry @!\nYou are not in service List',' ', [msg._from])
                    if text.lower() == "logout sb" and msg._from not in premium["myService"]:
                        noobcoder.sendMention(to, '「 Logout 」\n• Status : Faild\n> Sorry @!\nYou are not in service List',' ', [msg._from])
                    if text.lower() == "logout sb2" and msg._from not in premium["myService"]:
                        noobcoder.sendMention(to, '「 Logout 」\n• Status : Faild\n> Sorry @!\nYou are not in service List',' ', [msg._from])
                    if text.lower() == "logout sb3" and msg._from not in premium["myService"]:
                        noobcoder.sendMention(to, '「 Logout 」\n• Status : Faild\n> Sorry @!\nYou are not in service List',' ', [msg._from])
#==========================================
#==========================================
        if op.type == 55:
            print("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in wait['readPoint']:
                    if op.param2 in wait['ROM1'][op.param1]:
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                    else:
                        wait['ROM1'][op.param1][op.param2] = op.param2
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                        try:
                            if wait['lurkauto'] == True:
                                if len(wait['setTime'][op.param1]) % 5 == 0:
                                    anulurk(op.param1,wait)
                        except:pass
                elif op.param2 in wait['readPoints']:
                    wait['lurkt'][op.param1][op.param2][op.param3] = op.createdTime
                    wait['lurkp'][op.param1][op.param2][op.param3] = op.param2
                else:pass
            except:
                pass
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)
    
def run():
    while True:
        try:
            ops = noobcoderPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(noobcoderBot(op))
                   noobcoderPoll.setRevision(op.revision)
        except Exception as e:
            logError(e)
            
if __name__ == "__main__":
    run()
